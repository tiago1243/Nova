from flask import render_template, request, jsonify, session
from app import app
from nova_core import NovaCore
from openai_integration import OpenAIIntegration
from agent_core import NovaAgent
from workflow_engine import WorkflowEngine, WorkflowContext
from smart_learning import SmartLearningEngine
from goal_tracker import GoalTracker
from productivity_analytics import ProductivityAnalytics
import logging
import datetime

logger = logging.getLogger(__name__)

# Initialize Nova components
nova = NovaCore()
ai = OpenAIIntegration()
agent = NovaAgent(nova, ai)
workflow_engine = WorkflowEngine(nova, ai)
smart_learning = SmartLearningEngine(nova)
goal_tracker = GoalTracker(nova)
analytics = ProductivityAnalytics(nova, goal_tracker)

# Start the agent monitoring
agent.start_monitoring()

@app.route('/')
def index():
    """Main chat interface"""
    return render_template('index.html')

@app.route('/api/chat', methods=['POST'])
def chat():
    """Handle chat messages"""
    try:
        data = request.get_json()
        user_input = data.get('message', '').strip()
        
        if not user_input:
            return jsonify({'error': 'Empty message'}), 400

        # Check for special commands
        if user_input.lower() == 'help':
            return jsonify({
                'response': """🤖 **Nova AI Assistant - Commands**

**📝 Memory & Organization:**
• Tell me tasks, ideas, reminders, or notes
• Use hashtags like #project or #work to label entries
• "show memory" - see all entries
• "show category:task" - filter by category
• "show #tag" - filter by tags
• "clear memory" - reset everything
• I understand due dates: "tomorrow", "next week", "in 3 days"
• For recurring items: "daily", "weekly", "monthly"

**🚀 Agent Features:**
• "plan my day" - intelligent daily planning
• "agent status" - check autonomous agent status
• "insights" - get productivity analysis
• "analyze" - analyze your patterns and habits

**🎯 Smart Capabilities:**
• Proactive suggestions and reminders
• Pattern recognition and insights
• Intelligent task prioritization
• Automated workflow execution

Just talk to me naturally - I'll understand what you need!""",
                'type': 'help'
            })

        # Handle agent commands first (before storing as memory)
        user_input_lower = user_input.lower()
        
        # Daily planning command
        if any(phrase in user_input_lower for phrase in ["plan my day", "daily plan", "plan day"]):
            try:
                context = WorkflowContext(data={}, user_input=user_input)
                result = workflow_engine.execute_workflow("daily_planning", [
                    {"action": "analyze_tasks"},
                    {"action": "suggest_priorities"},
                    {"action": "generate_daily_plan"},
                    {"action": "smart_notifications"}
                ], context)
                
                # Extract daily plan from results
                daily_plan = None
                task_analysis = None
                for res in result.get('results', []):
                    if 'daily_plan' in res:
                        daily_plan = res['daily_plan']
                    if 'total_tasks' in res:
                        task_analysis = res
                
                response = "📅 **Your Daily Plan**\n\n"
                
                if task_analysis:
                    response += f"📊 **Task Overview**: {task_analysis.get('total_tasks', 0)} total tasks"
                    if task_analysis.get('urgent_tasks'):
                        response += f", {len(task_analysis['urgent_tasks'])} urgent"
                    if task_analysis.get('overdue_tasks'):
                        response += f", {len(task_analysis['overdue_tasks'])} overdue"
                    response += "\n\n"
                
                if daily_plan:
                    time_slots = {
                        'morning': '🌅 **Morning (9:00-12:00)**',
                        'afternoon': '☀️ **Afternoon (12:00-17:00)**', 
                        'evening': '🌆 **Evening (17:00-20:00)**',
                        'flexible': '⏰ **Flexible Time**'
                    }
                    
                    for slot, tasks in daily_plan.items():
                        if tasks and len(tasks) > 0:
                            response += f"{time_slots.get(slot, slot)}:\n"
                            for task in tasks:
                                response += f"• {task['text']}\n"
                            response += "\n"
                else:
                    response += "No specific tasks planned yet. Add some tasks and I'll help organize your day!"
                
                return jsonify({
                    'response': response,
                    'type': 'daily_plan'
                })
            except Exception as e:
                logger.error(f"Daily plan error: {e}")
                return jsonify({
                    'response': 'I had trouble generating your daily plan. Please try again.',
                    'type': 'error'
                })
        
        # Agent status command
        if any(phrase in user_input_lower for phrase in ["agent status", "nova status", "status"]):
            try:
                status = agent.get_agent_status()
                pending_actions = agent.get_pending_actions()
                
                response = "🤖 **Nova Agent Status**\n\n"
                response += f"Status: {'🟢 Active and monitoring' if status['active'] else '⚫ Inactive'}\n"
                response += f"Pending actions: {status['pending_actions']}\n"
                response += f"Actions completed today: {status['completed_actions_today']}\n\n"
                
                if pending_actions:
                    response += "📋 **Pending Actions**:\n"
                    for action in pending_actions[:5]:  # Show top 5
                        priority_emoji = "🔴" if action.priority >= 8 else "🟡" if action.priority >= 6 else "🔵"
                        response += f"{priority_emoji} {action.description}\n"
                else:
                    response += "✅ No pending actions - all systems running smoothly!"
                
                return jsonify({
                    'response': response,
                    'type': 'agent_status'
                })
            except Exception as e:
                logger.error(f"Agent status error: {e}")
                return jsonify({
                    'response': 'Unable to get agent status right now.',
                    'type': 'error'
                })
        
        # Insights command
        if any(phrase in user_input_lower for phrase in ["insights", "analyze", "analysis", "get insights"]):
            try:
                context = WorkflowContext(data={})
                result = workflow_engine.execute_workflow("insights_analysis", [
                    {"action": "analyze_tasks"},
                    {"action": "check_patterns"},
                    {"action": "suggest_priorities"},
                    {"action": "smart_notifications"}
                ], context)
                
                response = "📈 **Productivity Insights**\n\n"
                
                for res in result.get('results', []):
                    if 'total_tasks' in res:
                        response += f"📊 **Task Analysis**: {res['total_tasks']} total tasks\n"
                        if res.get('urgent_tasks'):
                            response += f"⚡ {len(res['urgent_tasks'])} urgent tasks need attention\n"
                        if res.get('overdue_tasks'):
                            response += f"🚨 {len(res['overdue_tasks'])} overdue tasks\n"
                        response += "\n"
                    
                    if 'suggestions' in res:
                        response += "💡 **Priority Suggestions**:\n"
                        for suggestion in res['suggestions'][:3]:
                            priority_emoji = "🔴" if suggestion['priority'] == 'urgent' else "🟡" if suggestion['priority'] == 'high' else "🔵"
                            response += f"{priority_emoji} {suggestion['action']}\n"
                        response += "\n"
                    
                    if 'most_active_times' in res:
                        top_time = res['most_active_times'][0] if res['most_active_times'] else None
                        if top_time:
                            response += f"⏰ **Peak Activity**: {top_time[0]}:00 ({top_time[1]} entries)\n\n"
                
                if result.get('summary'):
                    response += f"🎯 **Summary**: {result['summary']}"
                
                return jsonify({
                    'response': response,
                    'type': 'insights'
                })
            except Exception as e:
                logger.error(f"Insights error: {e}")
                return jsonify({
                    'response': 'Unable to generate insights right now.',
                    'type': 'error'
                })
        
        # Analytics command
        if any(phrase in user_input_lower for phrase in ["analytics", "productivity report", "performance"]):
            try:
                report = analytics.get_comprehensive_report()
                
                response = "📊 **Productivity Analytics**\n\n"
                
                current_week = report.get('current_week', {})
                response += f"📅 **This Week**: {current_week.get('avg_productivity_score', 0):.1f}/100 productivity score\n"
                response += f"📈 **Entries**: {current_week.get('total_entries', 0)} total, {current_week.get('avg_daily_entries', 0):.1f} daily average\n\n"
                
                trends = report.get('monthly_trends', {})
                trend_direction = trends.get('trend_direction', 'stable')
                trend_emoji = "📈" if trend_direction == 'improving' else "📉" if trend_direction == 'declining' else "➡️"
                response += f"{trend_emoji} **Trend**: {trend_direction.title()} over 30 days\n\n"
                
                focus = report.get('focus_analysis', {})
                focus_quality = focus.get('focus_quality', 'unknown')
                focus_emoji = "🎯" if focus_quality == 'excellent' else "👍" if focus_quality == 'good' else "⚠️"
                response += f"{focus_emoji} **Focus Quality**: {focus_quality.replace('_', ' ').title()}\n"
                
                if focus.get('recommendations'):
                    response += f"💡 **Focus Tip**: {focus['recommendations'][0]}\n\n"
                
                insights = report.get('key_insights', [])
                if insights:
                    response += "🔍 **Key Insights**:\n"
                    for insight in insights[:2]:
                        response += f"• {insight}\n"
                
                return jsonify({
                    'response': response,
                    'type': 'analytics'
                })
            except Exception as e:
                logger.error(f"Analytics error: {e}")
                return jsonify({
                    'response': 'Unable to generate analytics right now.',
                    'type': 'error'
                })
        
        # Goals command
        if any(phrase in user_input_lower for phrase in ["goals", "my goals", "goal status", "objectives"]):
            try:
                dashboard = goal_tracker.get_goal_dashboard()
                
                response = "🎯 **Goals Dashboard**\n\n"
                
                summary = dashboard.get('summary', {})
                response += f"📊 **Overview**: {summary.get('active_goals', 0)} active goals, {summary.get('completion_rate', 0):.1%} completion rate\n"
                
                if summary.get('overdue_goals', 0) > 0:
                    response += f"🚨 **Overdue**: {summary['overdue_goals']} goals need attention\n"
                
                upcoming = dashboard.get('upcoming_deadlines', [])
                if upcoming:
                    response += f"\n⏰ **Upcoming Deadlines**:\n"
                    for item in upcoming[:3]:
                        days = item.get('days_until', 0)
                        if item.get('type') == 'goal':
                            response += f"• {item['item']['title']} ({days} days)\n"
                        else:
                            response += f"• {item['item']['title']} milestone ({days} days)\n"
                
                suggestions = dashboard.get('suggestions', [])
                if suggestions:
                    response += f"\n💡 **Suggestions**:\n"
                    for suggestion in suggestions[:2]:
                        response += f"• {suggestion['suggestion']}\n"
                
                response += f"\nUse 'create goal [title]' to add new goals!"
                
                return jsonify({
                    'response': response,
                    'type': 'goals'
                })
            except Exception as e:
                logger.error(f"Goals error: {e}")
                return jsonify({
                    'response': 'Unable to get goals information right now.',
                    'type': 'error'
                })
        
        # Create goal command
        if user_input_lower.startswith('create goal'):
            try:
                title = user_input[11:].strip()  # Remove 'create goal' prefix
                if not title:
                    return jsonify({
                        'response': 'Please specify a goal title. Example: "create goal Learn Python programming"',
                        'type': 'error'
                    })
                
                goal_id = goal_tracker.create_goal(
                    title=title,
                    description=f"Goal created from chat: {title}",
                    category='general'
                )
                
                return jsonify({
                    'response': f"✅ **Goal Created**: {title}\n\nGoal ID: {goal_id}\nYou can add milestones and set deadlines for this goal.",
                    'type': 'goal_created'
                })
            except Exception as e:
                logger.error(f"Create goal error: {e}")
                return jsonify({
                    'response': 'Unable to create goal right now.',
                    'type': 'error'
                })
        
        # Learning insights command
        if any(phrase in user_input_lower for phrase in ["learning", "what have you learned", "my patterns", "behavior"]):
            try:
                insights = smart_learning.get_learning_insights()
                
                response = "🧠 **Learning Insights**\n\n"
                
                user_model = insights.get('user_model', {})
                response += f"👤 **Your Profile**:\n"
                response += f"• Work Style: {user_model.get('work_style', 'unknown').title()}\n"
                response += f"• Priority Style: {user_model.get('priority_style', 'unknown').title()}\n"
                response += f"• Communication: {user_model.get('communication_style', 'unknown').title()}\n\n"
                
                patterns = insights.get('key_patterns', {})
                peak_hours = patterns.get('peak_hours', [])
                if peak_hours:
                    hours_str = ', '.join([f"{h}:00" for h in peak_hours])
                    response += f"⏰ **Peak Hours**: {hours_str}\n"
                
                if patterns.get('primary_focus'):
                    response += f"🎯 **Primary Focus**: {patterns['primary_focus'].title()}\n"
                
                active_projects = patterns.get('active_projects', [])
                if active_projects:
                    response += f"📁 **Active Projects**: {', '.join(active_projects[:3])}\n"
                
                confidence = insights.get('adaptation_confidence', 0)
                confidence_level = "High" if confidence > 0.7 else "Medium" if confidence > 0.4 else "Building"
                response += f"\n🎯 **Adaptation Confidence**: {confidence_level} ({confidence:.1%})\n"
                
                # Get personalized suggestions
                suggestions = smart_learning.get_personalized_suggestions()
                if suggestions:
                    response += f"\n💡 **Personal Suggestions**:\n"
                    for suggestion in suggestions[:2]:
                        response += f"• {suggestion['message']}\n"
                
                return jsonify({
                    'response': response,
                    'type': 'learning'
                })
            except Exception as e:
                logger.error(f"Learning insights error: {e}")
                return jsonify({
                    'response': 'Unable to get learning insights right now.',
                    'type': 'error'
                })

        # Handle memory commands
        if user_input.lower().startswith('show'):
            return handle_memory_command(user_input)
        
        if user_input.lower() == 'clear memory':
            nova.clear_memory()
            return jsonify({
                'response': 'Memory cleared successfully.',
                'type': 'system'
            })

        # Check if this should trigger a workflow (for other contextual analysis)
        workflow_result = workflow_engine.execute_contextual_workflow(user_input)
        
        # Process normal input
        result = nova.process_input(user_input)
        
        # Get recent context for AI enhancement
        recent_entries = nova.memory_log[-5:] if len(nova.memory_log) > 5 else nova.memory_log
        
        # Generate base response
        base_response = f"Logged as {result['category']}: {result['entry']['text']}"
        if result['entry'].get('due_date'):
            base_response += f" (Due: {result['entry']['due_date']})"
        if result['entry'].get('recurring'):
            base_response += f" (Recurring: {result['entry']['recurring']})"

        # Enhance with AI if available
        if ai.is_available():
            enhanced_response = ai.enhance_response(user_input, result, recent_entries)
        else:
            enhanced_response = base_response

        # Add workflow insights if available
        if workflow_result and workflow_result.get('status') == 'completed':
            workflow_summary = workflow_result.get('summary', '')
            if workflow_summary and enhanced_response:
                enhanced_response += f"\n\n🤖 Agent Analysis: {workflow_summary}"
        
        # Update learning system with new entry
        smart_learning.analyze_user_behavior()
        
        # Get personalized suggestions
        suggestions = smart_learning.get_personalized_suggestions()
        if suggestions and len(suggestions) > 0 and enhanced_response:
            suggestion = suggestions[0]  # Show top suggestion
            enhanced_response += f"\n\n💡 Smart Tip: {suggestion['message']}"

        # Add clarification prompt if needed
        if result['needs_clarification']:
            if enhanced_response:
                enhanced_response += "\n\nWhen would you like to complete or be reminded of this?"
            else:
                enhanced_response = "When would you like to complete or be reminded of this?"

        return jsonify({
            'response': enhanced_response,
            'type': 'success',
            'entry': result['entry'],
            'workflow_result': workflow_result
        })

    except Exception as e:
        logger.error(f"Chat error: {e}")
        return jsonify({'error': 'Something went wrong. Please try again.'}), 500

def handle_memory_command(command):
    """Handle memory-related commands"""
    try:
        command_lower = command.lower()
        
        if command_lower == 'show memory':
            entries = nova.memory_log
            if not entries:
                return jsonify({
                    'response': 'Your memory is empty.',
                    'type': 'memory',
                    'entries': []
                })
            
            # Generate summary with AI if available
            summary = ai.generate_summary(entries) if ai.is_available() else None
            
            return jsonify({
                'response': f'Found {len(entries)} memory entries.',
                'type': 'memory',
                'entries': entries,
                'summary': summary
            })
        
        elif command_lower.startswith('show category:'):
            category = command_lower.split(':', 1)[1].strip()
            entries = nova.search_memory(category=category)
            
            return jsonify({
                'response': f'Found {len(entries)} entries in category "{category}".',
                'type': 'memory',
                'entries': entries
            })
        
        elif command_lower.startswith('show #'):
            # Extract hashtags
            tags = nova.extract_tags(command)
            if tags:
                entries = nova.search_memory(tags=tags)
                return jsonify({
                    'response': f'Found {len(entries)} entries with tags {", ".join(tags)}.',
                    'type': 'memory',
                    'entries': entries
                })
        
        # Smart search with AI
        elif command_lower.startswith('search ') or command_lower.startswith('find '):
            query = command[7:] if command_lower.startswith('search ') else command[5:]
            all_entries = nova.memory_log
            
            if ai.is_available():
                entries = ai.smart_search(query, all_entries)
            else:
                entries = nova.search_memory(query=query)
            
            return jsonify({
                'response': f'Found {len(entries)} entries matching "{query}".',
                'type': 'memory',
                'entries': entries
            })
        
        return jsonify({
            'response': 'Unknown memory command. Try "show memory", "show category:task", or "show #tag".',
            'type': 'error'
        })
        
    except Exception as e:
        logger.error(f"Memory command error: {e}")
        return jsonify({'error': 'Error processing memory command.'}), 500

@app.route('/api/stats')
def get_stats():
    """Get memory statistics"""
    try:
        stats = nova.get_memory_stats()
        return jsonify(stats)
    except Exception as e:
        logger.error(f"Stats error: {e}")
        # Return empty stats instead of error to prevent frontend issues
        return jsonify({
            'total_entries': 0,
            'categories': {},
            'recent_entries': []
        })

@app.route('/api/voice/process', methods=['POST'])
def process_voice():
    """Handle voice input processing"""
    try:
        data = request.get_json()
        transcript = data.get('transcript', '').strip()
        
        if not transcript:
            return jsonify({'error': 'No transcript provided'}), 400

        # Process the transcript as a regular chat message
        result = nova.process_input(transcript)
        
        # Get enhanced response
        if ai.is_available():
            recent_entries = nova.memory_log[-5:] if len(nova.memory_log) > 5 else nova.memory_log
            response = ai.enhance_response(transcript, result, recent_entries)
        else:
            response = f"Voice input logged as {result['category']}: {result['entry']['text']}"

        return jsonify({
            'response': response,
            'type': 'voice_success',
            'entry': result['entry'],
            'should_speak': True  # Indicate that this should be spoken back
        })

    except Exception as e:
        logger.error(f"Voice processing error: {e}")
        return jsonify({'error': 'Voice processing failed'}), 500

# ==================== AGENT ENDPOINTS ====================

@app.route('/api/agent/status')
def get_agent_status():
    """Get current agent status and capabilities"""
    try:
        status = agent.get_agent_status()
        pending_actions = agent.get_pending_actions()
        
        return jsonify({
            'status': status,
            'pending_actions': [
                {
                    'description': action.description,
                    'priority': action.priority,
                    'type': action.action_type,
                    'requires_approval': action.requires_approval
                } for action in pending_actions
            ]
        })
    except Exception as e:
        logger.error(f"Agent status error: {e}")
        return jsonify({'error': 'Unable to get agent status'}), 500

@app.route('/api/agent/actions', methods=['GET'])
def get_pending_actions():
    """Get all pending agent actions"""
    try:
        pending_actions = agent.get_pending_actions()
        return jsonify({
            'actions': [
                {
                    'index': i,
                    'description': action.description,
                    'priority': action.priority,
                    'type': action.action_type,
                    'parameters': action.parameters,
                    'requires_approval': action.requires_approval
                } for i, action in enumerate(pending_actions)
            ]
        })
    except Exception as e:
        logger.error(f"Get actions error: {e}")
        return jsonify({'error': 'Unable to get actions'}), 500

@app.route('/api/agent/actions/<int:action_index>/approve', methods=['POST'])
def approve_action(action_index):
    """Approve and execute a pending action"""
    try:
        success = agent.approve_action(action_index)
        if success:
            return jsonify({'message': 'Action approved and executed', 'success': True})
        else:
            return jsonify({'error': 'Invalid action index'}), 400
    except Exception as e:
        logger.error(f"Approve action error: {e}")
        return jsonify({'error': 'Unable to approve action'}), 500

@app.route('/api/agent/actions/<int:action_index>/dismiss', methods=['POST'])
def dismiss_action(action_index):
    """Dismiss a pending action"""
    try:
        success = agent.dismiss_action(action_index)
        if success:
            return jsonify({'message': 'Action dismissed', 'success': True})
        else:
            return jsonify({'error': 'Invalid action index'}), 400
    except Exception as e:
        logger.error(f"Dismiss action error: {e}")
        return jsonify({'error': 'Unable to dismiss action'}), 500

@app.route('/api/agent/preferences', methods=['GET', 'POST'])
def agent_preferences():
    """Get or update agent preferences"""
    try:
        if request.method == 'GET':
            return jsonify({'preferences': agent.user_preferences})
        
        elif request.method == 'POST':
            data = request.get_json()
            preferences = data.get('preferences', {})
            agent.update_preferences(preferences)
            return jsonify({'message': 'Preferences updated', 'preferences': agent.user_preferences})
    
    except Exception as e:
        logger.error(f"Agent preferences error: {e}")
        return jsonify({'error': 'Unable to process preferences'}), 500

@app.route('/api/workflows/execute', methods=['POST'])
def execute_workflow():
    """Execute a custom workflow"""
    try:
        data = request.get_json()
        workflow_name = data.get('name', 'custom_workflow')
        steps = data.get('steps', [])
        context_data = data.get('context', {})
        
        context = WorkflowContext(data=context_data)
        result = workflow_engine.execute_workflow(workflow_name, steps, context)
        
        return jsonify(result)
    
    except Exception as e:
        logger.error(f"Execute workflow error: {e}")
        return jsonify({'error': 'Unable to execute workflow'}), 500

@app.route('/api/workflows/active')
def get_active_workflows():
    """Get currently active workflows"""
    try:
        active = workflow_engine.get_active_workflows()
        return jsonify({'active_workflows': active})
    except Exception as e:
        logger.error(f"Get active workflows error: {e}")
        return jsonify({'error': 'Unable to get workflows'}), 500

@app.route('/api/workflows/history')
def get_workflow_history():
    """Get workflow execution history"""
    try:
        limit = request.args.get('limit', 10, type=int)
        history = workflow_engine.get_workflow_history(limit)
        return jsonify({'workflow_history': history})
    except Exception as e:
        logger.error(f"Get workflow history error: {e}")
        return jsonify({'error': 'Unable to get workflow history'}), 500

@app.route('/api/agent/insights')
def get_agent_insights():
    """Get proactive insights and analysis"""
    try:
        # Execute analysis workflow
        context = WorkflowContext(data={})
        result = workflow_engine.execute_workflow("insights_analysis", [
            {"action": "analyze_tasks"},
            {"action": "check_patterns"},
            {"action": "suggest_priorities"},
            {"action": "smart_notifications"}
        ], context)
        
        return jsonify({
            'insights': result.get('results', []),
            'summary': result.get('summary', ''),
            'generated_at': datetime.datetime.now().isoformat()
        })
    
    except Exception as e:
        logger.error(f"Get insights error: {e}")
        return jsonify({'error': 'Unable to generate insights'}), 500

@app.route('/api/agent/daily-plan')
def generate_daily_plan():
    """Generate an intelligent daily plan"""
    try:
        context = WorkflowContext(data={})
        result = workflow_engine.execute_workflow("daily_planning", [
            {"action": "analyze_tasks"},
            {"action": "suggest_priorities"},
            {"action": "generate_daily_plan"},
            {"action": "smart_notifications"}
        ], context)
        
        # Extract the daily plan from results
        daily_plan = None
        for res in result.get('results', []):
            if 'daily_plan' in res:
                daily_plan = res['daily_plan']
                break
        
        return jsonify({
            'daily_plan': daily_plan,
            'workflow_result': result,
            'generated_at': datetime.datetime.now().isoformat()
        })
    
    except Exception as e:
        logger.error(f"Daily plan error: {e}")
        return jsonify({'error': 'Unable to generate daily plan'}), 500

# ==================== ADVANCED FEATURES ====================

@app.route('/api/analytics/productivity')
def get_productivity_analytics():
    """Get comprehensive productivity analytics"""
    try:
        report = analytics.get_comprehensive_report()
        return jsonify(report)
    except Exception as e:
        logger.error(f"Analytics error: {e}")
        return jsonify({'error': 'Unable to generate analytics'}), 500

@app.route('/api/analytics/trends')
def get_productivity_trends():
    """Get productivity trends over time"""
    try:
        days = request.args.get('days', 30, type=int)
        trends = analytics.get_productivity_trends(days)
        return jsonify(trends)
    except Exception as e:
        logger.error(f"Trends error: {e}")
        return jsonify({'error': 'Unable to get trends'}), 500

@app.route('/api/analytics/focus')
def get_focus_analysis():
    """Get focus and attention analysis"""
    try:
        focus_data = analytics.get_focus_analysis()
        return jsonify(focus_data)
    except Exception as e:
        logger.error(f"Focus analysis error: {e}")
        return jsonify({'error': 'Unable to analyze focus'}), 500

@app.route('/api/goals', methods=['GET', 'POST'])
def manage_goals():
    """Manage goals - list or create"""
    try:
        if request.method == 'GET':
            status_filter = request.args.get('status', 'active')
            if status_filter == 'all':
                goals = list(goal_tracker.goals.values())
            else:
                from goal_tracker import GoalStatus
                status_enum = GoalStatus(status_filter)
                goals = goal_tracker.get_goals_by_status(status_enum)
            
            # Convert to serializable format
            goals_data = []
            for goal in goals:
                goal_dict = {
                    'id': goal.id,
                    'title': goal.title,
                    'description': goal.description,
                    'category': goal.category,
                    'priority': goal.priority.value,
                    'status': goal.status.value,
                    'progress_percentage': goal.progress_percentage,
                    'created_date': goal.created_date,
                    'target_date': goal.target_date,
                    'tags': goal.tags,
                    'milestones_count': len(goal.milestones)
                }
                goals_data.append(goal_dict)
            
            return jsonify({'goals': goals_data})
        
        elif request.method == 'POST':
            data = request.get_json()
            goal_id = goal_tracker.create_goal(
                title=data.get('title'),
                description=data.get('description', ''),
                category=data.get('category', 'general'),
                priority=data.get('priority', 'medium'),
                target_date=data.get('target_date'),
                tags=data.get('tags', [])
            )
            return jsonify({'goal_id': goal_id, 'message': 'Goal created successfully'})
    
    except Exception as e:
        logger.error(f"Goals error: {e}")
        return jsonify({'error': 'Unable to manage goals'}), 500

@app.route('/api/goals/<goal_id>/milestones', methods=['POST'])
def add_milestone(goal_id):
    """Add milestone to a goal"""
    try:
        data = request.get_json()
        success = goal_tracker.add_milestone(
            goal_id=goal_id,
            title=data.get('title'),
            description=data.get('description', ''),
            due_date=data.get('due_date')
        )
        
        if success:
            return jsonify({'message': 'Milestone added successfully'})
        else:
            return jsonify({'error': 'Goal not found'}), 404
    
    except Exception as e:
        logger.error(f"Milestone error: {e}")
        return jsonify({'error': 'Unable to add milestone'}), 500

@app.route('/api/goals/dashboard')
def get_goals_dashboard():
    """Get comprehensive goals dashboard"""
    try:
        dashboard = goal_tracker.get_goal_dashboard()
        return jsonify(dashboard)
    except Exception as e:
        logger.error(f"Goals dashboard error: {e}")
        return jsonify({'error': 'Unable to get goals dashboard'}), 500

@app.route('/api/learning/insights')
def get_learning_insights():
    """Get smart learning insights"""
    try:
        insights = smart_learning.get_learning_insights()
        return jsonify(insights)
    except Exception as e:
        logger.error(f"Learning insights error: {e}")
        return jsonify({'error': 'Unable to get learning insights'}), 500

@app.route('/api/learning/suggestions')
def get_personalized_suggestions():
    """Get personalized suggestions based on learning"""
    try:
        suggestions = smart_learning.get_personalized_suggestions()
        return jsonify({'suggestions': suggestions})
    except Exception as e:
        logger.error(f"Suggestions error: {e}")
        return jsonify({'error': 'Unable to get suggestions'}), 500

@app.route('/api/learning/predictions')
def get_predictions():
    """Get predictions for next actions"""
    try:
        recent_entries = nova.memory_log[-10:] if nova.memory_log else []
        predictions = smart_learning.predict_next_actions(recent_entries)
        return jsonify({'predictions': predictions})
    except Exception as e:
        logger.error(f"Predictions error: {e}")
        return jsonify({'error': 'Unable to get predictions'}), 500

@app.route('/api/comprehensive-analysis')
def get_comprehensive_analysis():
    """Get a comprehensive analysis combining all systems"""
    try:
        # Get data from all systems
        analytics_report = analytics.get_comprehensive_report()
        learning_insights = smart_learning.get_learning_insights()
        goals_dashboard = goal_tracker.get_goal_dashboard()
        agent_status = agent.get_agent_status()
        
        # Generate comprehensive insights
        comprehensive_analysis = {
            'generated_at': datetime.datetime.now().isoformat(),
            'productivity': {
                'current_week_score': analytics_report.get('current_week', {}).get('avg_productivity_score', 0),
                'trend': analytics_report.get('monthly_trends', {}).get('trend_direction', 'stable'),
                'focus_quality': analytics_report.get('focus_analysis', {}).get('focus_quality', 'unknown')
            },
            'learning': {
                'adaptation_confidence': learning_insights.get('adaptation_confidence', 0),
                'work_style': learning_insights.get('user_model', {}).get('work_style', 'balanced'),
                'peak_hours': learning_insights.get('key_patterns', {}).get('peak_hours', [])
            },
            'goals': {
                'active_goals': goals_dashboard.get('summary', {}).get('active_goals', 0),
                'completion_rate': goals_dashboard.get('summary', {}).get('completion_rate', 0),
                'overdue_goals': len(goals_dashboard.get('overdue_goals', []))
            },
            'agent': {
                'monitoring_active': agent_status.get('active', False),
                'pending_actions': agent_status.get('pending_actions', 0),
                'completed_today': agent_status.get('completed_actions_today', 0)
            },
            'key_insights': analytics_report.get('key_insights', []),
            'recommendations': analytics_report.get('recommendations', [])
        }
        
        return jsonify(comprehensive_analysis)
    
    except Exception as e:
        logger.error(f"Comprehensive analysis error: {e}")
        return jsonify({'error': 'Unable to generate comprehensive analysis'}), 500

# ==================== ERROR HANDLERS ====================

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500
