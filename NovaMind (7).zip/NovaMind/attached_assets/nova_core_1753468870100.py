import datetime
import re
import json
import os
import logging

logger = logging.getLogger(__name__)

class NovaCore:
    def __init__(self):
        self.memory_log = []
        self.memory_file = "nova_memory.json"
        self.awaiting_clarification = False
        self.current_entry = None
        self.load_memory()
        
        # Expanded category keywords from original code
        self.CATEGORY_KEYWORDS = {
            "task": [
                "do", "complete", "make", "build", "create", "finish", "setup", "develop",
                "design", "get done", "finish up", "carry out", "execute", "work on",
                "resolve", "fix", "implement", "write", "code", "plan", "organize"
            ],
            "idea": [
                "idea", "think", "concept", "invention", "vision", "plan", "brainstorm",
                "imagine", "suggestion", "proposal", "possibility", "consider", "dream"
            ],
            "reminder": [
                "remind", "remember", "note", "don't forget", "ping me", "set a reminder",
                "alert me", "notify me", "alarm", "prompt me"
            ],
            "note": [
                "note", "log", "write down", "record", "jot down", "memo", "capture",
                "document", "save this"
            ],
            "recurring_reminder": [
                "every", "daily", "weekly", "monthly", "annually", "each day", "each week",
                "each month", "each year", "repeat", "recur", "recurring"
            ]
        }

    def load_memory(self):
        """Load memory from JSON file"""
        if os.path.exists(self.memory_file):
            try:
                with open(self.memory_file, 'r') as f:
                    self.memory_log = json.load(f)
                logger.info(f"Loaded {len(self.memory_log)} memory entries")
            except Exception as e:
                logger.error(f"Error loading memory: {e}")
                self.memory_log = []

    def save_memory(self):
        """Save memory to JSON file"""
        try:
            with open(self.memory_file, 'w') as f:
                json.dump(self.memory_log, f, indent=4)
            logger.debug("Memory saved successfully")
        except Exception as e:
            logger.error(f"Error saving memory: {e}")

    def detect_category(self, text):
        """Detect category of user input based on keywords"""
        text_lower = text.lower()
        
        # Check recurring reminder keywords first
        for keyword in self.CATEGORY_KEYWORDS["recurring_reminder"]:
            if keyword in text_lower:
                return "recurring_reminder"
        
        # Then check other categories
        for category, keywords in self.CATEGORY_KEYWORDS.items():
            if category == "recurring_reminder":
                continue
            for keyword in keywords:
                if keyword in text_lower:
                    return category
        
        return "uncategorized"

    def extract_tags(self, text):
        """Extract hashtags from text"""
        return re.findall(r'#\w+', text)

    def parse_due_date(self, text):
        """Enhanced due date parsing from original code"""
        text = text.lower()
        now = datetime.datetime.now()

        # Simple relative dates
        if "today" in text:
            due = now
        elif "tomorrow" in text:
            due = now + datetime.timedelta(days=1)
        elif "day after tomorrow" in text:
            due = now + datetime.timedelta(days=2)
        elif "next week" in text:
            due = now + datetime.timedelta(weeks=1)
        elif "in " in text:
            # Try to find "in X days/hours/weeks/months"
            match = re.search(r'in (\d+) (day|days|hour|hours|week|weeks|month|months)', text)
            if match:
                amount = int(match.group(1))
                unit = match.group(2)
                if "day" in unit:
                    due = now + datetime.timedelta(days=amount)
                elif "hour" in unit:
                    due = now + datetime.timedelta(hours=amount)
                elif "week" in unit:
                    due = now + datetime.timedelta(weeks=amount)
                elif "month" in unit:
                    # Approximate a month as 30 days
                    due = now + datetime.timedelta(days=30*amount)
                else:
                    due = None
            else:
                due = None
        elif "next " in text:
            # Next weekday e.g. "next monday"
            weekdays = {
                "monday": 0, "tuesday": 1, "wednesday": 2, "thursday": 3,
                "friday": 4, "saturday": 5, "sunday": 6
            }
            for day_name, day_idx in weekdays.items():
                if f"next {day_name}" in text:
                    days_ahead = (day_idx - now.weekday() + 7) % 7
                    days_ahead = days_ahead if days_ahead != 0 else 7
                    due = now + datetime.timedelta(days=days_ahead)
                    break
            else:
                due = None
        else:
            # Try to parse YYYY-MM-DD or YYYY/MM/DD
            match = re.search(r'\b(\d{4})[-/](\d{1,2})[-/](\d{1,2})\b', text)
            if match:
                try:
                    year, month, day = map(int, match.groups())
                    due = datetime.datetime(year, month, day)
                except:
                    due = None
            else:
                due = None

        # Extract time if present (e.g., "at 3pm", "at 15:30")
        if due:
            time_match = re.search(r'at (\d{1,2})(?::(\d{2}))?\s*(am|pm)?', text)
            if time_match:
                hour = int(time_match.group(1))
                minute = int(time_match.group(2)) if time_match.group(2) else 0
                ampm = time_match.group(3)
                if ampm:
                    if ampm.lower() == 'pm' and hour != 12:
                        hour += 12
                    elif ampm.lower() == 'am' and hour == 12:
                        hour = 0
                due = due.replace(hour=hour, minute=minute, second=0, microsecond=0)

        if due:
            return due.strftime("%Y-%m-%d %H:%M:%S")
        return None

    def log_thought(self, category, content, tags, due_date=None, recurring=None):
        """Log a thought/entry to memory"""
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = {
            "timestamp": timestamp,
            "category": category,
            "text": content,
            "tags": tags,
            "due_date": due_date
        }
        if recurring:
            entry["recurring"] = recurring
        
        self.memory_log.append(entry)
        self.save_memory()
        self.current_entry = entry
        
        logger.info(f"Logged entry: {category} - {content}")
        return entry

    def search_memory(self, query=None, category=None, tags=None):
        """Search memory with various filters"""
        results = self.memory_log

        if category:
            results = [entry for entry in results if entry["category"] == category]
        
        if tags:
            if isinstance(tags, str):
                tags = [tags]
            results = [entry for entry in results if all(tag in entry["tags"] for tag in tags)]
        
        if query:
            query_lower = query.lower()
            results = [entry for entry in results if query_lower in entry["text"].lower()]

        return results

    def get_memory_stats(self):
        """Get statistics about memory entries"""
        total = len(self.memory_log)
        categories = {}
        
        for entry in self.memory_log:
            cat = entry["category"]
            categories[cat] = categories.get(cat, 0) + 1
        
        return {
            "total_entries": total,
            "categories": categories,
            "recent_entries": self.memory_log[-5:] if total > 0 else []
        }

    def clear_memory(self):
        """Clear all memory entries"""
        self.memory_log = []
        self.save_memory()
        logger.info("Memory cleared")

    def process_input(self, user_input):
        """Process user input and return structured response"""
        # Detect category
        category = self.detect_category(user_input)
        
        # Extract hashtags
        tags = self.extract_tags(user_input)
        
        # Parse due date
        due_date = self.parse_due_date(user_input)
        
        # Detect recurring info
        recurring = None
        rec_match = re.search(r'(daily|weekly|monthly|every \w+)', user_input.lower())
        if rec_match:
            recurring = rec_match.group()
            category = "recurring_reminder"
        
        # Log the thought
        entry = self.log_thought(category, user_input, tags, due_date, recurring)
        
        # Determine if clarification is needed
        needs_clarification = category in ["task", "reminder"] and not due_date and not recurring
        
        return {
            "entry": entry,
            "needs_clarification": needs_clarification,
            "category": category
        }
