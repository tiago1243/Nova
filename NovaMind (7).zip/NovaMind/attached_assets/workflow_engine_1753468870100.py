import datetime
import json
import logging
import asyncio
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, asdict
import re

logger = logging.getLogger(__name__)

@dataclass
class WorkflowContext:
    """Context passed between workflow steps"""
    data: Dict[str, Any]
    user_input: Optional[str] = None
    previous_results: List[Any] = None
    
    def __post_init__(self):
        if self.previous_results is None:
            self.previous_results = []

class WorkflowEngine:
    """Advanced workflow engine for autonomous task execution"""
    
    def __init__(self, nova_core, openai_integration=None):
        self.nova_core = nova_core
        self.ai = openai_integration
        self.registered_actions = {}
        self.active_workflows = {}
        self.workflow_history = []
        self._register_built_in_actions()
    
    def _register_built_in_actions(self):
        """Register built-in workflow actions"""
        
        @self.register_action("analyze_tasks")
        def analyze_tasks(context: WorkflowContext) -> Dict[str, Any]:
            """Analyze user's tasks and provide insights"""
            tasks = [entry for entry in self.nova_core.memory_log if entry['category'] == 'task']
            
            # Categorize tasks by urgency and project
            urgent_tasks = []
            project_tasks = {}
            overdue_tasks = []
            
            current_time = datetime.datetime.now()
            
            for task in tasks:
                # Check if overdue
                if task.get('due_date'):
                    try:
                        due_date = datetime.datetime.strptime(task['due_date'], "%Y-%m-%d %H:%M:%S")
                        if due_date < current_time:
                            overdue_tasks.append(task)
                        elif (due_date - current_time).days <= 1:
                            urgent_tasks.append(task)
                    except ValueError:
                        pass
                
                # Group by project tags
                for tag in task.get('tags', []):
                    if tag.startswith('#'):
                        if tag not in project_tasks:
                            project_tasks[tag] = []
                        project_tasks[tag].append(task)
            
            return {
                'total_tasks': len(tasks),
                'urgent_tasks': urgent_tasks,
                'overdue_tasks': overdue_tasks,
                'project_breakdown': project_tasks,
                'analysis_time': datetime.datetime.now().isoformat()
            }
        
        @self.register_action("suggest_priorities")
        def suggest_priorities(context: WorkflowContext) -> Dict[str, Any]:
            """Suggest task priorities based on analysis"""
            task_analysis = context.data.get('task_analysis', {})
            suggestions = []
            
            # High priority: overdue tasks
            if task_analysis.get('overdue_tasks'):
                suggestions.append({
                    'priority': 'urgent',
                    'action': 'Complete overdue tasks first',
                    'items': task_analysis['overdue_tasks'][:3]
                })
            
            # Medium priority: urgent tasks
            if task_analysis.get('urgent_tasks'):
                suggestions.append({
                    'priority': 'high',
                    'action': 'Focus on upcoming deadlines',
                    'items': task_analysis['urgent_tasks'][:3]
                })
            
            # Project-based priorities
            project_breakdown = task_analysis.get('project_breakdown', {})
            for project, tasks in project_breakdown.items():
                if len(tasks) >= 3:
                    suggestions.append({
                        'priority': 'medium',
                        'action': f'Make progress on {project} project',
                        'items': tasks[:2]
                    })
            
            return {
                'suggestions': suggestions,
                'recommendation': self._generate_priority_recommendation(suggestions)
            }
        
        @self.register_action("generate_daily_plan")
        def generate_daily_plan(context: WorkflowContext) -> Dict[str, Any]:
            """Generate a daily plan based on tasks and priorities"""
            priorities = context.data.get('priorities', {})
            suggestions = priorities.get('suggestions', [])
            
            plan = {
                'morning': [],
                'afternoon': [],
                'evening': [],
                'flexible': []
            }
            
            # Distribute tasks by priority and time preference
            for suggestion in suggestions:
                items = suggestion.get('items', [])
                priority = suggestion.get('priority', 'medium')
                
                if priority == 'urgent':
                    plan['morning'].extend(items[:2])
                elif priority == 'high':
                    plan['afternoon'].extend(items[:2])
                else:
                    plan['flexible'].extend(items[:1])
            
            return {
                'daily_plan': plan,
                'total_planned_tasks': sum(len(v) for v in plan.values()),
                'plan_date': datetime.datetime.now().strftime("%Y-%m-%d")
            }
        
        @self.register_action("check_patterns")
        def check_patterns(context: WorkflowContext) -> Dict[str, Any]:
            """Analyze user behavior patterns"""
            entries = self.nova_core.memory_log[-50:]  # Last 50 entries
            
            patterns = {
                'most_active_times': [],
                'preferred_categories': {},
                'tag_usage': {},
                'productivity_trends': []
            }
            
            # Analyze time patterns
            hour_activity = {}
            for entry in entries:
                try:
                    hour = datetime.datetime.strptime(entry['timestamp'], "%Y-%m-%d %H:%M:%S").hour
                    hour_activity[hour] = hour_activity.get(hour, 0) + 1
                except ValueError:
                    continue
            
            if hour_activity:
                patterns['most_active_times'] = sorted(hour_activity.items(), key=lambda x: x[1], reverse=True)[:3]
            
            # Category preferences
            for entry in entries:
                category = entry['category']
                patterns['preferred_categories'][category] = patterns['preferred_categories'].get(category, 0) + 1
            
            # Tag usage
            for entry in entries:
                for tag in entry.get('tags', []):
                    patterns['tag_usage'][tag] = patterns['tag_usage'].get(tag, 0) + 1
            
            return patterns
        
        @self.register_action("smart_notifications")
        def smart_notifications(context: WorkflowContext) -> Dict[str, Any]:
            """Generate smart, contextual notifications"""
            patterns = context.data.get('patterns', {})
            task_analysis = context.data.get('task_analysis', {})
            
            notifications = []
            current_hour = datetime.datetime.now().hour
            
            # Time-based notifications
            most_active_times = patterns.get('most_active_times', [])
            if most_active_times and current_hour in [time[0] for time in most_active_times[:2]]:
                notifications.append({
                    'type': 'productivity_tip',
                    'message': f"This is one of your most productive hours ({current_hour}:00). Consider tackling important tasks now.",
                    'priority': 'medium'
                })
            
            # Task-based notifications
            if task_analysis.get('urgent_tasks'):
                notifications.append({
                    'type': 'task_reminder',
                    'message': f"You have {len(task_analysis['urgent_tasks'])} urgent tasks due soon.",
                    'priority': 'high',
                    'action': 'show_urgent_tasks'
                })
            
            # Project momentum notifications
            tag_usage = patterns.get('tag_usage', {})
            for tag, count in sorted(tag_usage.items(), key=lambda x: x[1], reverse=True)[:3]:
                if count >= 3 and tag.startswith('#'):
                    notifications.append({
                        'type': 'project_momentum',
                        'message': f"Great progress on {tag}! Consider what's next for this project.",
                        'priority': 'low',
                        'action': f'suggest_next_steps:{tag}'
                    })
            
            return {'notifications': notifications}
        
        @self.register_action("auto_categorize")
        def auto_categorize(context: WorkflowContext) -> Dict[str, Any]:
            """Automatically categorize and enhance new entries"""
            user_input = context.user_input or ""
            
            # Enhanced categorization using AI if available
            if self.ai and self.ai.is_available():
                try:
                    intent_analysis = self.ai.analyze_intent(user_input)
                    if intent_analysis:
                        return {
                            'suggested_category': intent_analysis.get('category'),
                            'priority': intent_analysis.get('priority'),
                            'urgency': intent_analysis.get('urgency'),
                            'suggested_tags': intent_analysis.get('suggested_tags', []),
                            'confidence': intent_analysis.get('confidence', 0.5)
                        }
                except Exception as e:
                    logger.error(f"AI categorization failed: {e}")
            
            # Fallback to rule-based categorization
            return self.nova_core.process_input(user_input)
    
    def register_action(self, name: str):
        """Decorator to register workflow actions"""
        def decorator(func: Callable):
            self.registered_actions[name] = func
            return func
        return decorator
    
    def execute_workflow(self, workflow_name: str, steps: List[Dict], context: WorkflowContext = None) -> Dict[str, Any]:
        """Execute a workflow with given steps"""
        if not context:
            context = WorkflowContext(data={})
        
        workflow_id = f"{workflow_name}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.active_workflows[workflow_id] = {
            'name': workflow_name,
            'started': datetime.datetime.now().isoformat(),
            'steps': steps,
            'current_step': 0,
            'status': 'running',
            'context': context
        }
        
        results = []
        
        try:
            for i, step in enumerate(steps):
                self.active_workflows[workflow_id]['current_step'] = i
                
                action_name = step.get('action')
                if action_name not in self.registered_actions:
                    logger.warning(f"Unknown action: {action_name}")
                    continue
                
                # Execute action
                action_func = self.registered_actions[action_name]
                result = action_func(context)
                results.append(result)
                
                # Update context with result
                context.data[action_name] = result
                context.previous_results.append(result)
                
                logger.info(f"Workflow {workflow_name} - Step {i+1}/{len(steps)} completed: {action_name}")
            
            # Mark workflow as completed
            self.active_workflows[workflow_id]['status'] = 'completed'
            self.active_workflows[workflow_id]['completed'] = datetime.datetime.now().isoformat()
            self.active_workflows[workflow_id]['results'] = results
            
            # Move to history
            self.workflow_history.append(self.active_workflows[workflow_id])
            del self.active_workflows[workflow_id]
            
            return {
                'workflow_id': workflow_id,
                'status': 'completed',
                'results': results,
                'summary': self._generate_workflow_summary(workflow_name, results)
            }
            
        except Exception as e:
            logger.error(f"Workflow {workflow_name} failed: {e}")
            self.active_workflows[workflow_id]['status'] = 'failed'
            self.active_workflows[workflow_id]['error'] = str(e)
            
            return {
                'workflow_id': workflow_id,
                'status': 'failed',
                'error': str(e)
            }
    
    def _generate_priority_recommendation(self, suggestions: List[Dict]) -> str:
        """Generate a priority recommendation based on suggestions"""
        if not suggestions:
            return "No urgent tasks found. Great time to work on long-term projects!"
        
        urgent_count = len([s for s in suggestions if s.get('priority') == 'urgent'])
        high_count = len([s for s in suggestions if s.get('priority') == 'high'])
        
        if urgent_count > 0:
            return f"Focus on {urgent_count} urgent items first, then move to high-priority tasks."
        elif high_count > 0:
            return f"Start with {high_count} high-priority tasks to stay ahead of deadlines."
        else:
            return "Good task balance! Consider working on project milestones for steady progress."
    
    def _generate_workflow_summary(self, workflow_name: str, results: List[Any]) -> str:
        """Generate a human-readable summary of workflow results"""
        summaries = []
        
        for result in results:
            if isinstance(result, dict):
                if 'total_tasks' in result:
                    summaries.append(f"Analyzed {result['total_tasks']} tasks")
                if 'suggestions' in result:
                    summaries.append(f"Generated {len(result['suggestions'])} priority suggestions")
                if 'daily_plan' in result:
                    plan = result['daily_plan']
                    total_planned = sum(len(v) for v in plan.values())
                    summaries.append(f"Created daily plan with {total_planned} scheduled tasks")
                if 'notifications' in result:
                    summaries.append(f"Generated {len(result['notifications'])} smart notifications")
        
        return f"Workflow '{workflow_name}' completed: " + "; ".join(summaries)
    
    def get_active_workflows(self) -> Dict[str, Any]:
        """Get currently active workflows"""
        return self.active_workflows.copy()
    
    def get_workflow_history(self, limit: int = 10) -> List[Dict]:
        """Get recent workflow history"""
        return self.workflow_history[-limit:]
    
    def create_contextual_workflow(self, user_input: str, memory_context: List[Dict]) -> Optional[List[Dict]]:
        """Create a contextual workflow based on user input and memory"""
        
        # Analyze user input for workflow triggers
        input_lower = user_input.lower()
        
        # Daily planning workflow
        if any(phrase in input_lower for phrase in ["plan my day", "daily plan", "what should i do", "organize tasks"]):
            return [
                {"action": "analyze_tasks"},
                {"action": "suggest_priorities"},
                {"action": "generate_daily_plan"},
                {"action": "smart_notifications"}
            ]
        
        # Project analysis workflow
        project_tags = re.findall(r'#\w+', user_input)
        if project_tags or "project" in input_lower:
            return [
                {"action": "analyze_tasks"},
                {"action": "check_patterns"},
                {"action": "suggest_priorities"}
            ]
        
        # Pattern analysis workflow
        if any(phrase in input_lower for phrase in ["analyze", "patterns", "insights", "productivity"]):
            return [
                {"action": "check_patterns"},
                {"action": "analyze_tasks"},
                {"action": "smart_notifications"}
            ]
        
        # Smart entry processing workflow
        if len(user_input) > 10:  # Substantial input
            return [
                {"action": "auto_categorize"}
            ]
        
        return None
    
    def execute_contextual_workflow(self, user_input: str) -> Optional[Dict[str, Any]]:
        """Execute a contextual workflow based on user input"""
        
        # Create workflow based on context
        workflow_steps = self.create_contextual_workflow(user_input, self.nova_core.memory_log)
        
        if not workflow_steps:
            return None
        
        # Create context with user input
        context = WorkflowContext(
            data={},
            user_input=user_input
        )
        
        # Execute the workflow
        return self.execute_workflow("contextual_analysis", workflow_steps, context)