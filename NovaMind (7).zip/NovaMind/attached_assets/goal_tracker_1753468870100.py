import datetime
import json
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from enum import Enum

logger = logging.getLogger(__name__)

class GoalStatus(Enum):
    ACTIVE = "active"
    COMPLETED = "completed"
    PAUSED = "paused"
    CANCELLED = "cancelled"

class GoalPriority(Enum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    URGENT = 4

@dataclass
class Milestone:
    id: str
    title: str
    description: str
    due_date: Optional[str]
    completed: bool = False
    completed_date: Optional[str] = None

@dataclass
class Goal:
    id: str
    title: str
    description: str
    category: str
    priority: GoalPriority
    status: GoalStatus
    created_date: str
    target_date: Optional[str] = None
    completed_date: Optional[str] = None
    milestones: List[Milestone] = None
    tags: List[str] = None
    progress_percentage: float = 0.0
    
    def __post_init__(self):
        if self.milestones is None:
            self.milestones = []
        if self.tags is None:
            self.tags = []

class GoalTracker:
    """Advanced goal tracking and achievement system"""
    
    def __init__(self, nova_core):
        self.nova_core = nova_core
        self.goals_file = "goals.json"
        self.goals = {}
        self.goal_counter = 0
        self.load_goals()
    
    def load_goals(self):
        """Load goals from file"""
        try:
            with open(self.goals_file, 'r') as f:
                data = json.load(f)
                self.goal_counter = data.get('counter', 0)
                
                goals_data = data.get('goals', {})
                for goal_id, goal_dict in goals_data.items():
                    # Convert back to Goal object
                    milestones = [Milestone(**m) for m in goal_dict.get('milestones', [])]
                    goal_dict['milestones'] = milestones
                    goal_dict['priority'] = GoalPriority(goal_dict['priority'])
                    goal_dict['status'] = GoalStatus(goal_dict['status'])
                    self.goals[goal_id] = Goal(**goal_dict)
                    
            logger.info(f"Loaded {len(self.goals)} goals")
        except (FileNotFoundError, json.JSONDecodeError, ValueError):
            logger.info("No goals found, starting fresh")
    
    def save_goals(self):
        """Save goals to file"""
        try:
            # Convert goals to serializable format
            goals_data = {}
            for goal_id, goal in self.goals.items():
                goal_dict = asdict(goal)
                goal_dict['priority'] = goal.priority.value
                goal_dict['status'] = goal.status.value
                goals_data[goal_id] = goal_dict
            
            data = {
                'counter': self.goal_counter,
                'goals': goals_data,
                'last_updated': datetime.datetime.now().isoformat()
            }
            
            with open(self.goals_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving goals: {e}")
    
    def create_goal(self, title: str, description: str, category: str, 
                   priority: str = "medium", target_date: Optional[str] = None,
                   tags: List[str] = None) -> str:
        """Create a new goal"""
        self.goal_counter += 1
        goal_id = f"goal_{self.goal_counter}"
        
        # Convert priority string to enum
        priority_map = {
            'low': GoalPriority.LOW,
            'medium': GoalPriority.MEDIUM,
            'high': GoalPriority.HIGH,
            'urgent': GoalPriority.URGENT
        }
        priority_enum = priority_map.get(priority.lower(), GoalPriority.MEDIUM)
        
        goal = Goal(
            id=goal_id,
            title=title,
            description=description,
            category=category,
            priority=priority_enum,
            status=GoalStatus.ACTIVE,
            created_date=datetime.datetime.now().isoformat(),
            target_date=target_date,
            tags=tags or []
        )
        
        self.goals[goal_id] = goal
        self.save_goals()
        
        return goal_id
    
    def add_milestone(self, goal_id: str, title: str, description: str, 
                     due_date: Optional[str] = None) -> bool:
        """Add a milestone to a goal"""
        if goal_id not in self.goals:
            return False
        
        milestone_id = f"{goal_id}_m{len(self.goals[goal_id].milestones) + 1}"
        milestone = Milestone(
            id=milestone_id,
            title=title,
            description=description,
            due_date=due_date
        )
        
        self.goals[goal_id].milestones.append(milestone)
        self._update_goal_progress(goal_id)
        self.save_goals()
        
        return True
    
    def complete_milestone(self, goal_id: str, milestone_id: str) -> bool:
        """Mark a milestone as completed"""
        if goal_id not in self.goals:
            return False
        
        goal = self.goals[goal_id]
        for milestone in goal.milestones:
            if milestone.id == milestone_id:
                milestone.completed = True
                milestone.completed_date = datetime.datetime.now().isoformat()
                break
        else:
            return False
        
        self._update_goal_progress(goal_id)
        
        # Check if goal is complete
        if goal.progress_percentage >= 100:
            self.complete_goal(goal_id)
        
        self.save_goals()
        return True
    
    def complete_goal(self, goal_id: str) -> bool:
        """Mark a goal as completed"""
        if goal_id not in self.goals:
            return False
        
        goal = self.goals[goal_id]
        goal.status = GoalStatus.COMPLETED
        goal.completed_date = datetime.datetime.now().isoformat()
        goal.progress_percentage = 100.0
        
        self.save_goals()
        return True
    
    def _update_goal_progress(self, goal_id: str):
        """Update goal progress based on milestone completion"""
        goal = self.goals[goal_id]
        
        if not goal.milestones:
            return
        
        completed_milestones = sum(1 for m in goal.milestones if m.completed)
        total_milestones = len(goal.milestones)
        
        goal.progress_percentage = (completed_milestones / total_milestones) * 100
    
    def get_goals_by_status(self, status: GoalStatus) -> List[Goal]:
        """Get goals filtered by status"""
        return [goal for goal in self.goals.values() if goal.status == status]
    
    def get_goals_by_category(self, category: str) -> List[Goal]:
        """Get goals filtered by category"""
        return [goal for goal in self.goals.values() if goal.category.lower() == category.lower()]
    
    def get_overdue_goals(self) -> List[Goal]:
        """Get goals that are overdue"""
        current_time = datetime.datetime.now()
        overdue_goals = []
        
        for goal in self.goals.values():
            if goal.status == GoalStatus.ACTIVE and goal.target_date:
                try:
                    target_date = datetime.datetime.fromisoformat(goal.target_date)
                    if target_date < current_time:
                        overdue_goals.append(goal)
                except ValueError:
                    continue
        
        return overdue_goals
    
    def get_upcoming_deadlines(self, days_ahead: int = 7) -> List[Dict[str, Any]]:
        """Get goals with deadlines in the next N days"""
        current_time = datetime.datetime.now()
        future_time = current_time + datetime.timedelta(days=days_ahead)
        upcoming = []
        
        for goal in self.goals.values():
            if goal.status == GoalStatus.ACTIVE:
                # Check goal deadline
                if goal.target_date:
                    try:
                        target_date = datetime.datetime.fromisoformat(goal.target_date)
                        if current_time <= target_date <= future_time:
                            days_until = (target_date - current_time).days
                            upcoming.append({
                                'type': 'goal',
                                'item': goal,
                                'days_until': days_until,
                                'date': goal.target_date
                            })
                    except ValueError:
                        continue
                
                # Check milestone deadlines
                for milestone in goal.milestones:
                    if not milestone.completed and milestone.due_date:
                        try:
                            due_date = datetime.datetime.fromisoformat(milestone.due_date)
                            if current_time <= due_date <= future_time:
                                days_until = (due_date - current_time).days
                                upcoming.append({
                                    'type': 'milestone',
                                    'item': milestone,
                                    'goal': goal,
                                    'days_until': days_until,
                                    'date': milestone.due_date
                                })
                        except ValueError:
                            continue
        
        return sorted(upcoming, key=lambda x: x['days_until'])
    
    def analyze_goal_progress(self) -> Dict[str, Any]:
        """Analyze overall goal progress and patterns"""
        all_goals = list(self.goals.values())
        active_goals = [g for g in all_goals if g.status == GoalStatus.ACTIVE]
        completed_goals = [g for g in all_goals if g.status == GoalStatus.COMPLETED]
        
        # Calculate completion rate
        total_goals = len(all_goals)
        completion_rate = len(completed_goals) / total_goals if total_goals > 0 else 0
        
        # Analyze by category
        category_stats = {}
        for goal in all_goals:
            cat = goal.category
            if cat not in category_stats:
                category_stats[cat] = {'total': 0, 'completed': 0, 'active': 0}
            
            category_stats[cat]['total'] += 1
            if goal.status == GoalStatus.COMPLETED:
                category_stats[cat]['completed'] += 1
            elif goal.status == GoalStatus.ACTIVE:
                category_stats[cat]['active'] += 1
        
        # Calculate average progress for active goals
        avg_progress = 0
        if active_goals:
            avg_progress = sum(g.progress_percentage for g in active_goals) / len(active_goals)
        
        # Find most productive category
        most_productive_category = None
        best_completion_rate = 0
        for cat, stats in category_stats.items():
            if stats['total'] > 0:
                cat_completion_rate = stats['completed'] / stats['total']
                if cat_completion_rate > best_completion_rate:
                    best_completion_rate = cat_completion_rate
                    most_productive_category = cat
        
        return {
            'total_goals': total_goals,
            'active_goals': len(active_goals),
            'completed_goals': len(completed_goals),
            'completion_rate': completion_rate,
            'average_progress': avg_progress,
            'category_stats': category_stats,
            'most_productive_category': most_productive_category,
            'overdue_goals': len(self.get_overdue_goals())
        }
    
    def get_goal_suggestions(self) -> List[Dict[str, Any]]:
        """Generate suggestions for goal management"""
        suggestions = []
        
        # Analyze recent memory entries for potential goals
        recent_entries = self.nova_core.memory_log[-20:]
        
        # Look for repeated themes that could become goals
        themes = {}
        for entry in recent_entries:
            for tag in entry.get('tags', []):
                if tag.startswith('#'):
                    themes[tag] = themes.get(tag, 0) + 1
        
        # Suggest goals for frequent themes
        for theme, count in themes.items():
            if count >= 3:
                # Check if we already have a goal for this theme
                existing_goal = any(theme in goal.tags for goal in self.goals.values())
                if not existing_goal:
                    suggestions.append({
                        'type': 'new_goal',
                        'suggestion': f"Consider creating a goal for {theme} project",
                        'theme': theme,
                        'evidence_count': count,
                        'confidence': min(count / 5.0, 0.9)
                    })
        
        # Suggest milestone creation for goals without milestones
        for goal in self.goals.values():
            if goal.status == GoalStatus.ACTIVE and not goal.milestones:
                suggestions.append({
                    'type': 'add_milestones',
                    'suggestion': f"Break down '{goal.title}' into smaller milestones",
                    'goal_id': goal.id,
                    'confidence': 0.8
                })
        
        # Suggest deadline setting for goals without target dates
        for goal in self.goals.values():
            if goal.status == GoalStatus.ACTIVE and not goal.target_date:
                suggestions.append({
                    'type': 'set_deadline',
                    'suggestion': f"Set a target date for '{goal.title}'",
                    'goal_id': goal.id,
                    'confidence': 0.7
                })
        
        return suggestions
    
    def extract_goals_from_entries(self) -> List[Dict[str, Any]]:
        """Automatically extract potential goals from memory entries"""
        potential_goals = []
        
        # Look for goal-indicating keywords
        goal_keywords = [
            'achieve', 'accomplish', 'goal', 'objective', 'target', 'aim',
            'complete', 'finish', 'build', 'create', 'develop', 'learn',
            'master', 'improve', 'become', 'get better at'
        ]
        
        for entry in self.nova_core.memory_log:
            text_lower = entry['text'].lower()
            
            # Check for goal indicators
            has_goal_keywords = any(keyword in text_lower for keyword in goal_keywords)
            has_long_term_thinking = any(phrase in text_lower for phrase in [
                'by the end of', 'within', 'in the next', 'this year', 'this month'
            ])
            
            if has_goal_keywords or has_long_term_thinking:
                potential_goals.append({
                    'text': entry['text'],
                    'category': entry['category'],
                    'tags': entry.get('tags', []),
                    'timestamp': entry['timestamp'],
                    'confidence': 0.6 if has_goal_keywords else 0.4
                })
        
        return potential_goals
    
    def get_goal_dashboard(self) -> Dict[str, Any]:
        """Get a comprehensive goal dashboard"""
        analysis = self.analyze_goal_progress()
        upcoming = self.get_upcoming_deadlines()
        overdue = self.get_overdue_goals()
        suggestions = self.get_goal_suggestions()
        
        return {
            'summary': analysis,
            'upcoming_deadlines': upcoming[:5],  # Next 5 deadlines
            'overdue_goals': [{'id': g.id, 'title': g.title, 'target_date': g.target_date} for g in overdue],
            'suggestions': suggestions[:3],  # Top 3 suggestions
            'recent_completions': [
                {'id': g.id, 'title': g.title, 'completed_date': g.completed_date}
                for g in sorted(
                    [g for g in self.goals.values() if g.status == GoalStatus.COMPLETED],
                    key=lambda x: x.completed_date or '',
                    reverse=True
                )[:3]
            ]
        }