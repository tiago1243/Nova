import os
import json
import logging
from openai import OpenAI

logger = logging.getLogger(__name__)

class OpenAIIntegration:
    def __init__(self):
        self.api_key = os.environ.get("OPENAI_API_KEY")
        if not self.api_key:
            logger.warning("OpenAI API key not found. AI features will be limited.")
            self.client = None
        else:
            self.client = OpenAI(api_key=self.api_key)

    def is_available(self):
        """Check if OpenAI integration is available"""
        return self.client is not None

    def enhance_response(self, user_input, nova_response, context=None):
        """Enhance Nova's response using OpenAI"""
        if not self.is_available():
            return str(nova_response) if nova_response else "I've processed your request."

        try:
            # Create context-aware prompt
            system_prompt = """You are Nova, an advanced AI assistant like Jarvis. You help users manage tasks, ideas, reminders, and notes with personality and intelligence. 

Key characteristics:
- Friendly, helpful, and slightly witty
- Proactive in suggesting improvements
- Context-aware and memory-conscious
- Focused on productivity and organization

You just processed a user input and logged it to memory. Provide a helpful, personalized response that acknowledges what was logged and offers relevant suggestions or follow-ups."""

            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"User said: '{user_input}'\nI logged this as: {json.dumps(nova_response, indent=2)}\n\nProvide a helpful response as Nova."}
            ]

            if context:
                messages.insert(1, {"role": "system", "content": f"Recent context: {json.dumps(context, indent=2)}"})

            # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
            # do not change this unless explicitly requested by the user
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=messages,
                max_tokens=300,
                temperature=0.7
            )

            return response.choices[0].message.content

        except Exception as e:
            logger.error(f"OpenAI API error: {e}")
            return str(nova_response) if nova_response else "I've processed your request."

    def analyze_intent(self, user_input):
        """Analyze user intent for better categorization"""
        if not self.is_available():
            return None

        try:
            # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
            # do not change this unless explicitly requested by the user
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {
                        "role": "system",
                        "content": """Analyze the user's intent and categorize their input. Return JSON with:
                        {
                            "category": "task|idea|reminder|note|recurring_reminder|question|command",
                            "priority": "low|medium|high",
                            "urgency": "low|medium|high",
                            "suggested_tags": ["tag1", "tag2"],
                            "confidence": 0.0-1.0
                        }"""
                    },
                    {"role": "user", "content": user_input}
                ],
                response_format={"type": "json_object"},
                max_tokens=150
            )

            return json.loads(response.choices[0].message.content)

        except Exception as e:
            logger.error(f"Intent analysis error: {e}")
            return None

    def smart_search(self, query, memory_entries):
        """Use AI to perform semantic search on memory entries"""
        if not self.is_available() or not memory_entries:
            return memory_entries

        try:
            # Prepare memory context
            memory_context = "\n".join([
                f"{i+1}. [{entry['category']}] {entry['text']} (Tags: {', '.join(entry['tags'])})"
                for i, entry in enumerate(memory_entries)
            ])

            # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
            # do not change this unless explicitly requested by the user
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {
                        "role": "system",
                        "content": """You are helping search through memory entries. Given a search query and numbered memory entries, return a JSON array of the most relevant entry numbers (1-based indexing) in order of relevance.

                        Return format: {"relevant_entries": [1, 3, 5], "explanation": "brief explanation"}"""
                    },
                    {
                        "role": "user",
                        "content": f"Search query: '{query}'\n\nMemory entries:\n{memory_context}"
                    }
                ],
                response_format={"type": "json_object"},
                max_tokens=200
            )

            result = json.loads(response.choices[0].message.content)
            relevant_indices = [i-1 for i in result.get("relevant_entries", []) if 0 < i <= len(memory_entries)]
            
            return [memory_entries[i] for i in relevant_indices]

        except Exception as e:
            logger.error(f"Smart search error: {e}")
            return memory_entries

    def generate_summary(self, entries):
        """Generate a summary of memory entries"""
        if not self.is_available() or not entries:
            return "No entries to summarize."

        try:
            entries_text = "\n".join([
                f"- [{entry['category']}] {entry['text']} (Due: {entry.get('due_date', 'None')})"
                for entry in entries
            ])

            # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
            # do not change this unless explicitly requested by the user
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {
                        "role": "system",
                        "content": "Provide a concise summary of these memory entries, highlighting key tasks, important reminders, and overall themes."
                    },
                    {"role": "user", "content": entries_text}
                ],
                max_tokens=200
            )

            return response.choices[0].message.content

        except Exception as e:
            logger.error(f"Summary generation error: {e}")
            return "Unable to generate summary at this time."
