import datetime
import json
import logging
import re
from typing import Dict, List, Optional, Any
from collections import defaultdict, Counter
import statistics

logger = logging.getLogger(__name__)

class SmartLearningEngine:
    """Advanced learning system that adapts to user behavior"""
    
    def __init__(self, nova_core):
        self.nova_core = nova_core
        self.learning_file = "smart_learning.json"
        self.patterns = {
            'time_preferences': {},
            'category_patterns': {},
            'productivity_patterns': {},
            'language_patterns': {},
            'project_patterns': {},
            'completion_patterns': {}
        }
        self.user_model = {
            'preferred_times': [],
            'work_style': 'balanced',  # focused, balanced, flexible
            'priority_style': 'deadline',  # deadline, importance, balanced
            'communication_style': 'concise',  # verbose, concise, minimal
            'notification_preference': 'moderate',  # high, moderate, low
            'project_approach': 'sequential'  # parallel, sequential, mixed
        }
        self.load_learning_data()
    
    def load_learning_data(self):
        """Load learning data from file"""
        try:
            with open(self.learning_file, 'r') as f:
                data = json.load(f)
                self.patterns = data.get('patterns', self.patterns)
                self.user_model = data.get('user_model', self.user_model)
        except (FileNotFoundError, json.JSONDecodeError):
            logger.info("No learning data found, starting fresh")
    
    def save_learning_data(self):
        """Save learning data to file"""
        try:
            data = {
                'patterns': self.patterns,
                'user_model': self.user_model,
                'last_updated': datetime.datetime.now().isoformat()
            }
            with open(self.learning_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving learning data: {e}")
    
    def analyze_user_behavior(self):
        """Continuously analyze and learn from user behavior"""
        entries = self.nova_core.memory_log[-50:]  # Last 50 entries for analysis
        
        if len(entries) < 10:
            return
        
        # Analyze time patterns
        self._analyze_time_patterns(entries)
        
        # Analyze category preferences
        self._analyze_category_patterns(entries)
        
        # Analyze productivity patterns
        self._analyze_productivity_patterns(entries)
        
        # Analyze language patterns
        self._analyze_language_patterns(entries)
        
        # Analyze project patterns
        self._analyze_project_patterns(entries)
        
        # Update user model
        self._update_user_model()
        
        # Save learning data
        self.save_learning_data()
    
    def _analyze_time_patterns(self, entries: List[Dict]):
        """Analyze when user is most active and productive"""
        time_activity = defaultdict(int)
        category_times = defaultdict(list)
        
        for entry in entries:
            try:
                timestamp = datetime.datetime.strptime(entry['timestamp'], "%Y-%m-%d %H:%M:%S")
                hour = timestamp.hour
                day_of_week = timestamp.weekday()
                
                time_activity[hour] += 1
                category_times[entry['category']].append(hour)
                
                # Track day patterns
                day_key = f"day_{day_of_week}"
                if day_key not in self.patterns['time_preferences']:
                    self.patterns['time_preferences'][day_key] = 0
                self.patterns['time_preferences'][day_key] += 1
                
            except ValueError:
                continue
        
        # Find peak hours
        if time_activity:
            peak_hours = sorted(time_activity.items(), key=lambda x: x[1], reverse=True)[:3]
            self.patterns['time_preferences']['peak_hours'] = [hour for hour, count in peak_hours]
        
        # Find preferred times by category
        for category, hours in category_times.items():
            if len(hours) >= 3:
                avg_hour = statistics.mean(hours)
                self.patterns['time_preferences'][f"{category}_preferred_time"] = avg_hour
    
    def _analyze_category_patterns(self, entries: List[Dict]):
        """Analyze user's category usage patterns"""
        category_counts = Counter([entry['category'] for entry in entries])
        category_sequences = []
        
        # Analyze category transitions
        for i in range(len(entries) - 1):
            current_cat = entries[i]['category']
            next_cat = entries[i + 1]['category']
            category_sequences.append((current_cat, next_cat))
        
        # Update patterns
        self.patterns['category_patterns']['counts'] = dict(category_counts)
        self.patterns['category_patterns']['transitions'] = Counter(category_sequences).most_common(10)
        
        # Determine primary focus
        top_category = category_counts.most_common(1)[0] if category_counts else ('task', 1)
        self.patterns['category_patterns']['primary_focus'] = top_category[0]
    
    def _analyze_productivity_patterns(self, entries: List[Dict]):
        """Analyze productivity patterns and completion rates"""
        tasks = [e for e in entries if e['category'] == 'task']
        
        if not tasks:
            return
        
        # Analyze task complexity (by length and tags)
        task_complexities = []
        for task in tasks:
            complexity = len(task['text']) + len(task.get('tags', [])) * 10
            task_complexities.append(complexity)
        
        if task_complexities:
            self.patterns['productivity_patterns']['avg_task_complexity'] = statistics.mean(task_complexities)
        
        # Analyze project distribution
        project_tags = [tag for task in tasks for tag in task.get('tags', []) if tag.startswith('#')]
        project_distribution = Counter(project_tags)
        self.patterns['productivity_patterns']['active_projects'] = dict(project_distribution.most_common(5))
        
        # Analyze due date patterns
        due_date_usage = len([t for t in tasks if t.get('due_date')]) / len(tasks) if tasks else 0
        self.patterns['productivity_patterns']['due_date_usage'] = due_date_usage
    
    def _analyze_language_patterns(self, entries: List[Dict]):
        """Analyze user's language and communication patterns"""
        all_text = ' '.join([entry['text'] for entry in entries])
        
        # Analyze text length preferences
        text_lengths = [len(entry['text']) for entry in entries]
        if text_lengths:
            avg_length = statistics.mean(text_lengths)
            self.patterns['language_patterns']['avg_text_length'] = avg_length
        
        # Analyze common words and phrases
        words = re.findall(r'\b\w+\b', all_text.lower())
        common_words = Counter(words).most_common(20)
        self.patterns['language_patterns']['common_words'] = common_words
        
        # Analyze hashtag usage
        hashtags = re.findall(r'#\w+', all_text)
        hashtag_usage = len(hashtags) / len(entries) if entries else 0
        self.patterns['language_patterns']['hashtag_usage'] = hashtag_usage
    
    def _analyze_project_patterns(self, entries: List[Dict]):
        """Analyze how user manages projects"""
        project_entries = defaultdict(list)
        
        for entry in entries:
            for tag in entry.get('tags', []):
                if tag.startswith('#'):
                    project_entries[tag].append(entry)
        
        # Analyze project engagement patterns
        for project, project_entries_list in project_entries.items():
            if len(project_entries_list) >= 3:
                # Calculate time between entries
                timestamps = []
                for entry in project_entries_list:
                    try:
                        ts = datetime.datetime.strptime(entry['timestamp'], "%Y-%m-%d %H:%M:%S")
                        timestamps.append(ts)
                    except ValueError:
                        continue
                
                if len(timestamps) >= 2:
                    timestamps.sort()
                    intervals = [(timestamps[i+1] - timestamps[i]).days for i in range(len(timestamps)-1)]
                    avg_interval = statistics.mean(intervals) if intervals else 0
                    
                    self.patterns['project_patterns'][project] = {
                        'entry_count': len(project_entries_list),
                        'avg_interval_days': avg_interval,
                        'categories': Counter([e['category'] for e in project_entries_list])
                    }
    
    def _update_user_model(self):
        """Update the user behavioral model based on patterns"""
        # Determine work style
        if self.patterns['productivity_patterns'].get('avg_task_complexity', 0) > 100:
            self.user_model['work_style'] = 'focused'
        elif len(self.patterns['productivity_patterns'].get('active_projects', {})) > 3:
            self.user_model['work_style'] = 'flexible'
        else:
            self.user_model['work_style'] = 'balanced'
        
        # Determine priority style
        due_date_usage = self.patterns['productivity_patterns'].get('due_date_usage', 0)
        if due_date_usage > 0.7:
            self.user_model['priority_style'] = 'deadline'
        elif due_date_usage < 0.3:
            self.user_model['priority_style'] = 'importance'
        else:
            self.user_model['priority_style'] = 'balanced'
        
        # Determine communication style
        avg_length = self.patterns['language_patterns'].get('avg_text_length', 50)
        if avg_length > 100:
            self.user_model['communication_style'] = 'verbose'
        elif avg_length < 30:
            self.user_model['communication_style'] = 'minimal'
        else:
            self.user_model['communication_style'] = 'concise'
        
        # Update preferred times
        peak_hours = self.patterns['time_preferences'].get('peak_hours', [])
        self.user_model['preferred_times'] = peak_hours
    
    def get_personalized_suggestions(self) -> List[Dict[str, Any]]:
        """Generate personalized suggestions based on learned patterns"""
        suggestions = []
        current_time = datetime.datetime.now()
        current_hour = current_time.hour
        
        # Time-based suggestions
        peak_hours = self.user_model.get('preferred_times', [])
        if current_hour in peak_hours:
            suggestions.append({
                'type': 'productivity_tip',
                'message': f"This is one of your peak productivity hours ({current_hour}:00). Consider working on important tasks now.",
                'confidence': 0.8,
                'action': 'suggest_important_tasks'
            })
        
        # Project suggestions
        active_projects = self.patterns['project_patterns']
        for project, data in active_projects.items():
            if data['avg_interval_days'] > 7:  # Haven't worked on project in a while
                suggestions.append({
                    'type': 'project_reminder',
                    'message': f"You haven't updated {project} in {data['avg_interval_days']:.0f} days. Consider making progress?",
                    'confidence': 0.7,
                    'action': f'suggest_project_work:{project}'
                })
        
        # Work style suggestions
        work_style = self.user_model.get('work_style', 'balanced')
        if work_style == 'focused':
            suggestions.append({
                'type': 'focus_tip',
                'message': "Based on your work style, consider blocking time for deep work on complex tasks.",
                'confidence': 0.6,
                'action': 'suggest_focus_time'
            })
        elif work_style == 'flexible':
            suggestions.append({
                'type': 'flexibility_tip',
                'message': "You work well with multiple projects. Consider switching tasks if you feel stuck.",
                'confidence': 0.6,
                'action': 'suggest_task_switch'
            })
        
        return suggestions
    
    def predict_next_actions(self, recent_entries: List[Dict]) -> List[Dict[str, Any]]:
        """Predict likely next actions based on patterns"""
        predictions = []
        
        if not recent_entries:
            return predictions
        
        last_entry = recent_entries[-1]
        last_category = last_entry['category']
        
        # Predict based on category transitions
        transitions = dict(self.patterns['category_patterns'].get('transitions', []))
        likely_next = None
        max_count = 0
        
        for (from_cat, to_cat), count in transitions.items():
            if from_cat == last_category and count > max_count:
                likely_next = to_cat
                max_count = count
        
        if likely_next:
            predictions.append({
                'type': 'category_prediction',
                'predicted_category': likely_next,
                'confidence': min(max_count / 10.0, 0.9),
                'suggestion': f"You often follow {last_category} entries with {likely_next} entries."
            })
        
        # Predict based on time patterns
        current_hour = datetime.datetime.now().hour
        preferred_time = self.patterns['time_preferences'].get(f"{last_category}_preferred_time")
        
        if preferred_time and abs(current_hour - preferred_time) <= 1:
            predictions.append({
                'type': 'time_prediction',
                'message': f"This is typically when you work on {last_category} items.",
                'confidence': 0.7,
                'suggestion': f"Good time to continue with {last_category} work."
            })
        
        return predictions
    
    def get_adaptive_response_style(self) -> Dict[str, Any]:
        """Get response style adapted to user preferences"""
        style = self.user_model.get('communication_style', 'concise')
        
        return {
            'length': 'short' if style == 'minimal' else 'long' if style == 'verbose' else 'medium',
            'detail_level': 'low' if style == 'minimal' else 'high' if style == 'verbose' else 'medium',
            'formality': 'casual' if style == 'minimal' else 'professional',
            'emoji_usage': 'none' if style == 'verbose' else 'moderate'
        }
    
    def learn_from_feedback(self, user_feedback: str, context: Dict[str, Any]):
        """Learn from user feedback to improve suggestions"""
        feedback_lower = user_feedback.lower()
        
        # Learn from positive feedback
        if any(word in feedback_lower for word in ['good', 'great', 'helpful', 'perfect', 'yes', 'correct']):
            if context.get('suggestion_type'):
                suggestion_type = context['suggestion_type']
                if 'positive_feedback' not in self.patterns:
                    self.patterns['positive_feedback'] = {}
                self.patterns['positive_feedback'][suggestion_type] = self.patterns['positive_feedback'].get(suggestion_type, 0) + 1
        
        # Learn from negative feedback
        elif any(word in feedback_lower for word in ['no', 'wrong', 'bad', 'not helpful', 'incorrect']):
            if context.get('suggestion_type'):
                suggestion_type = context['suggestion_type']
                if 'negative_feedback' not in self.patterns:
                    self.patterns['negative_feedback'] = {}
                self.patterns['negative_feedback'][suggestion_type] = self.patterns['negative_feedback'].get(suggestion_type, 0) + 1
        
        self.save_learning_data()
    
    def get_learning_insights(self) -> Dict[str, Any]:
        """Get insights about what the system has learned"""
        return {
            'user_model': self.user_model,
            'key_patterns': {
                'peak_hours': self.patterns['time_preferences'].get('peak_hours', []),
                'primary_focus': self.patterns['category_patterns'].get('primary_focus', 'unknown'),
                'active_projects': list(self.patterns['project_patterns'].keys())[:5],
                'avg_task_complexity': self.patterns['productivity_patterns'].get('avg_task_complexity', 0)
            },
            'adaptation_confidence': self._calculate_adaptation_confidence()
        }
    
    def _calculate_adaptation_confidence(self) -> float:
        """Calculate how confident the system is in its user model"""
        total_entries = len(self.nova_core.memory_log)
        
        if total_entries < 10:
            return 0.2
        elif total_entries < 50:
            return 0.5
        elif total_entries < 100:
            return 0.7
        else:
            return 0.9