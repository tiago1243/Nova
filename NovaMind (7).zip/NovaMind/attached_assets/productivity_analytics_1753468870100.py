import datetime
import json
import logging
from typing import Dict, List, Optional, Any, Tuple
from collections import defaultdict, Counter
import statistics
import re

logger = logging.getLogger(__name__)

class ProductivityAnalytics:
    """Advanced productivity analytics and performance tracking"""
    
    def __init__(self, nova_core, goal_tracker=None):
        self.nova_core = nova_core
        self.goal_tracker = goal_tracker
        self.analytics_file = "productivity_analytics.json"
        self.daily_stats = {}
        self.weekly_stats = {}
        self.monthly_stats = {}
        self.load_analytics()
    
    def load_analytics(self):
        """Load analytics data from file"""
        try:
            with open(self.analytics_file, 'r') as f:
                data = json.load(f)
                self.daily_stats = data.get('daily_stats', {})
                self.weekly_stats = data.get('weekly_stats', {})
                self.monthly_stats = data.get('monthly_stats', {})
        except (FileNotFoundError, json.JSONDecodeError):
            logger.info("No analytics data found, starting fresh")
    
    def save_analytics(self):
        """Save analytics data to file"""
        try:
            data = {
                'daily_stats': self.daily_stats,
                'weekly_stats': self.weekly_stats,
                'monthly_stats': self.monthly_stats,
                'last_updated': datetime.datetime.now().isoformat()
            }
            with open(self.analytics_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving analytics: {e}")
    
    def update_daily_stats(self):
        """Update daily productivity statistics"""
        today = datetime.datetime.now().strftime("%Y-%m-%d")
        
        # Get today's entries
        today_entries = [
            entry for entry in self.nova_core.memory_log
            if entry['timestamp'].startswith(today)
        ]
        
        if not today_entries:
            return
        
        # Calculate daily metrics
        daily_data = {
            'date': today,
            'total_entries': len(today_entries),
            'categories': Counter([entry['category'] for entry in today_entries]),
            'tags_used': len(set([tag for entry in today_entries for tag in entry.get('tags', [])])),
            'entries_with_due_dates': len([e for e in today_entries if e.get('due_date')]),
            'productivity_score': self._calculate_daily_productivity_score(today_entries),
            'focus_areas': self._identify_focus_areas(today_entries),
            'time_distribution': self._analyze_time_distribution(today_entries),
            'complexity_score': self._calculate_complexity_score(today_entries)
        }
        
        self.daily_stats[today] = daily_data
        self.save_analytics()
    
    def _calculate_daily_productivity_score(self, entries: List[Dict]) -> float:
        """Calculate a daily productivity score (0-100)"""
        if not entries:
            return 0.0
        
        score = 0.0
        
        # Base points for activity
        score += min(len(entries) * 5, 30)  # Max 30 points for entries
        
        # Points for planning (entries with due dates)
        planning_entries = [e for e in entries if e.get('due_date')]
        score += min(len(planning_entries) * 10, 20)  # Max 20 points for planning
        
        # Points for variety (different categories)
        categories = set([entry['category'] for entry in entries])
        score += min(len(categories) * 5, 15)  # Max 15 points for variety
        
        # Points for project work (entries with tags)
        tagged_entries = [e for e in entries if e.get('tags')]
        score += min(len(tagged_entries) * 3, 15)  # Max 15 points for project work
        
        # Points for complexity (longer, more detailed entries)
        avg_length = statistics.mean([len(entry['text']) for entry in entries])
        if avg_length > 50:
            score += min((avg_length - 50) / 10, 20)  # Max 20 points for complexity
        
        return min(score, 100.0)
    
    def _identify_focus_areas(self, entries: List[Dict]) -> List[str]:
        """Identify main focus areas for the day"""
        # Count tags and categories
        tag_counts = Counter([tag for entry in entries for tag in entry.get('tags', [])])
        category_counts = Counter([entry['category'] for entry in entries])
        
        focus_areas = []
        
        # Top tags (projects)
        for tag, count in tag_counts.most_common(3):
            if count >= 2:
                focus_areas.append(f"Project: {tag}")
        
        # Top category if significant
        top_category = category_counts.most_common(1)[0] if category_counts else None
        if top_category and top_category[1] >= 3:
            focus_areas.append(f"Category: {top_category[0]}")
        
        return focus_areas
    
    def _analyze_time_distribution(self, entries: List[Dict]) -> Dict[str, int]:
        """Analyze when entries were made throughout the day"""
        time_buckets = {
            'morning': 0,    # 6-12
            'afternoon': 0,  # 12-18
            'evening': 0,    # 18-22
            'night': 0       # 22-6
        }
        
        for entry in entries:
            try:
                timestamp = datetime.datetime.strptime(entry['timestamp'], "%Y-%m-%d %H:%M:%S")
                hour = timestamp.hour
                
                if 6 <= hour < 12:
                    time_buckets['morning'] += 1
                elif 12 <= hour < 18:
                    time_buckets['afternoon'] += 1
                elif 18 <= hour < 22:
                    time_buckets['evening'] += 1
                else:
                    time_buckets['night'] += 1
            except ValueError:
                continue
        
        return time_buckets
    
    def _calculate_complexity_score(self, entries: List[Dict]) -> float:
        """Calculate average complexity of entries"""
        if not entries:
            return 0.0
        
        complexity_scores = []
        for entry in entries:
            score = 0
            
            # Length contributes to complexity
            score += min(len(entry['text']) / 10, 10)
            
            # Tags indicate project complexity
            score += len(entry.get('tags', [])) * 2
            
            # Due dates indicate planning complexity
            if entry.get('due_date'):
                score += 3
            
            # Recurring items are complex to set up
            if entry.get('recurring'):
                score += 5
            
            complexity_scores.append(score)
        
        return statistics.mean(complexity_scores)
    
    def get_weekly_summary(self, weeks_back: int = 0) -> Dict[str, Any]:
        """Get weekly productivity summary"""
        target_date = datetime.datetime.now() - datetime.timedelta(weeks=weeks_back)
        week_start = target_date - datetime.timedelta(days=target_date.weekday())
        week_end = week_start + datetime.timedelta(days=6)
        
        week_entries = []
        for entry in self.nova_core.memory_log:
            try:
                entry_date = datetime.datetime.strptime(entry['timestamp'], "%Y-%m-%d %H:%M:%S")
                if week_start <= entry_date <= week_end:
                    week_entries.append(entry)
            except ValueError:
                continue
        
        if not week_entries:
            return {'week_start': week_start.strftime("%Y-%m-%d"), 'entries': 0}
        
        # Group by day
        daily_breakdown = defaultdict(list)
        for entry in week_entries:
            day = entry['timestamp'][:10]
            daily_breakdown[day].append(entry)
        
        # Calculate metrics
        total_entries = len(week_entries)
        avg_daily_entries = total_entries / 7
        most_productive_day = max(daily_breakdown.items(), key=lambda x: len(x[1])) if daily_breakdown else None
        
        category_distribution = Counter([entry['category'] for entry in week_entries])
        tag_usage = Counter([tag for entry in week_entries for tag in entry.get('tags', [])])
        
        # Calculate weekly productivity score
        weekly_scores = []
        for day, entries in daily_breakdown.items():
            score = self._calculate_daily_productivity_score(entries)
            weekly_scores.append(score)
        
        avg_productivity = statistics.mean(weekly_scores) if weekly_scores else 0
        
        return {
            'week_start': week_start.strftime("%Y-%m-%d"),
            'week_end': week_end.strftime("%Y-%m-%d"),
            'total_entries': total_entries,
            'avg_daily_entries': round(avg_daily_entries, 1),
            'most_productive_day': {
                'date': most_productive_day[0],
                'entries': len(most_productive_day[1])
            } if most_productive_day else None,
            'category_distribution': dict(category_distribution),
            'top_tags': dict(tag_usage.most_common(5)),
            'avg_productivity_score': round(avg_productivity, 1),
            'daily_breakdown': {
                day: {
                    'entries': len(entries),
                    'productivity_score': round(self._calculate_daily_productivity_score(entries), 1)
                }
                for day, entries in daily_breakdown.items()
            }
        }
    
    def get_productivity_trends(self, days: int = 30) -> Dict[str, Any]:
        """Analyze productivity trends over time"""
        cutoff_date = datetime.datetime.now() - datetime.timedelta(days=days)
        
        # Group entries by day
        daily_data = defaultdict(list)
        for entry in self.nova_core.memory_log:
            try:
                entry_date = datetime.datetime.strptime(entry['timestamp'], "%Y-%m-%d %H:%M:%S")
                if entry_date >= cutoff_date:
                    day = entry_date.strftime("%Y-%m-%d")
                    daily_data[day].append(entry)
            except ValueError:
                continue
        
        # Calculate daily metrics
        daily_metrics = []
        for day, entries in daily_data.items():
            metrics = {
                'date': day,
                'entries': len(entries),
                'productivity_score': self._calculate_daily_productivity_score(entries),
                'complexity_score': self._calculate_complexity_score(entries),
                'planning_entries': len([e for e in entries if e.get('due_date')])
            }
            daily_metrics.append(metrics)
        
        daily_metrics.sort(key=lambda x: x['date'])
        
        if not daily_metrics:
            return {'trend': 'insufficient_data'}
        
        # Calculate trends
        entry_counts = [m['entries'] for m in daily_metrics]
        productivity_scores = [m['productivity_score'] for m in daily_metrics]
        
        # Simple trend calculation (comparing first and second half)
        mid_point = len(daily_metrics) // 2
        if mid_point > 0:
            first_half_avg = statistics.mean(productivity_scores[:mid_point])
            second_half_avg = statistics.mean(productivity_scores[mid_point:])
            trend_direction = 'improving' if second_half_avg > first_half_avg else 'declining' if second_half_avg < first_half_avg else 'stable'
        else:
            trend_direction = 'stable'
        
        return {
            'period_days': days,
            'total_entries': sum(entry_counts),
            'avg_daily_entries': statistics.mean(entry_counts) if entry_counts else 0,
            'avg_productivity_score': statistics.mean(productivity_scores) if productivity_scores else 0,
            'trend_direction': trend_direction,
            'best_day': max(daily_metrics, key=lambda x: x['productivity_score']) if daily_metrics else None,
            'most_active_day': max(daily_metrics, key=lambda x: x['entries']) if daily_metrics else None,
            'daily_data': daily_metrics[-14:]  # Last 14 days for visualization
        }
    
    def get_focus_analysis(self) -> Dict[str, Any]:
        """Analyze focus and attention patterns"""
        entries = self.nova_core.memory_log[-100:]  # Last 100 entries
        
        if not entries:
            return {'analysis': 'insufficient_data'}
        
        # Analyze context switching
        category_switches = 0
        project_switches = 0
        
        for i in range(1, len(entries)):
            prev_entry = entries[i-1]
            curr_entry = entries[i]
            
            # Category switching
            if prev_entry['category'] != curr_entry['category']:
                category_switches += 1
            
            # Project switching (tag-based)
            prev_tags = set(prev_entry.get('tags', []))
            curr_tags = set(curr_entry.get('tags', []))
            if prev_tags and curr_tags and not prev_tags.intersection(curr_tags):
                project_switches += 1
        
        # Calculate focus metrics
        total_transitions = len(entries) - 1
        context_switch_rate = category_switches / total_transitions if total_transitions > 0 else 0
        project_switch_rate = project_switches / total_transitions if total_transitions > 0 else 0
        
        # Analyze session lengths (consecutive entries in same category/project)
        category_sessions = self._calculate_session_lengths(entries, 'category')
        project_sessions = self._calculate_session_lengths_by_tags(entries)
        
        # Focus quality assessment
        focus_quality = self._assess_focus_quality(context_switch_rate, project_switch_rate, category_sessions)
        
        return {
            'context_switch_rate': round(context_switch_rate, 3),
            'project_switch_rate': round(project_switch_rate, 3),
            'avg_category_session_length': round(statistics.mean(category_sessions), 1) if category_sessions else 0,
            'avg_project_session_length': round(statistics.mean(project_sessions), 1) if project_sessions else 0,
            'focus_quality': focus_quality,
            'recommendations': self._generate_focus_recommendations(focus_quality, context_switch_rate)
        }
    
    def _calculate_session_lengths(self, entries: List[Dict], field: str) -> List[int]:
        """Calculate session lengths for a given field"""
        sessions = []
        current_session_length = 1
        
        for i in range(1, len(entries)):
            if entries[i][field] == entries[i-1][field]:
                current_session_length += 1
            else:
                sessions.append(current_session_length)
                current_session_length = 1
        
        if current_session_length > 0:
            sessions.append(current_session_length)
        
        return sessions
    
    def _calculate_session_lengths_by_tags(self, entries: List[Dict]) -> List[int]:
        """Calculate session lengths based on tag overlap"""
        sessions = []
        current_session_length = 1
        
        for i in range(1, len(entries)):
            prev_tags = set(entries[i-1].get('tags', []))
            curr_tags = set(entries[i].get('tags', []))
            
            # Consider it the same session if there's tag overlap or both have no tags
            if (prev_tags and curr_tags and prev_tags.intersection(curr_tags)) or (not prev_tags and not curr_tags):
                current_session_length += 1
            else:
                sessions.append(current_session_length)
                current_session_length = 1
        
        if current_session_length > 0:
            sessions.append(current_session_length)
        
        return sessions
    
    def _assess_focus_quality(self, context_switch_rate: float, project_switch_rate: float, 
                            category_sessions: List[int]) -> str:
        """Assess overall focus quality"""
        avg_session = statistics.mean(category_sessions) if category_sessions else 0
        
        # High focus: low switching, longer sessions
        if context_switch_rate < 0.3 and avg_session > 3:
            return 'excellent'
        elif context_switch_rate < 0.5 and avg_session > 2:
            return 'good'
        elif context_switch_rate < 0.7 and avg_session > 1.5:
            return 'moderate'
        else:
            return 'needs_improvement'
    
    def _generate_focus_recommendations(self, focus_quality: str, switch_rate: float) -> List[str]:
        """Generate recommendations for improving focus"""
        recommendations = []
        
        if focus_quality == 'needs_improvement':
            recommendations.append("Consider batching similar tasks together to reduce context switching")
            recommendations.append("Try the Pomodoro technique for focused work sessions")
        
        if switch_rate > 0.6:
            recommendations.append("High context switching detected - plan your tasks in advance")
            recommendations.append("Set specific time blocks for different types of work")
        
        if focus_quality in ['moderate', 'needs_improvement']:
            recommendations.append("Use the 'Plan My Day' feature to organize tasks by priority")
            recommendations.append("Consider setting goals for projects to maintain long-term focus")
        
        return recommendations
    
    def get_comprehensive_report(self) -> Dict[str, Any]:
        """Generate a comprehensive productivity report"""
        self.update_daily_stats()
        
        current_week = self.get_weekly_summary(0)
        previous_week = self.get_weekly_summary(1)
        trends = self.get_productivity_trends(30)
        focus_analysis = self.get_focus_analysis()
        
        # Calculate week-over-week comparison
        week_comparison = None
        if current_week.get('avg_productivity_score') and previous_week.get('avg_productivity_score'):
            change = current_week['avg_productivity_score'] - previous_week['avg_productivity_score']
            week_comparison = {
                'change': round(change, 1),
                'direction': 'improved' if change > 0 else 'declined' if change < 0 else 'maintained'
            }
        
        # Integration with goals if available
        goal_progress = None
        if self.goal_tracker:
            goal_analysis = self.goal_tracker.analyze_goal_progress()
            goal_progress = {
                'active_goals': goal_analysis['active_goals'],
                'completion_rate': goal_analysis['completion_rate'],
                'avg_progress': goal_analysis['average_progress']
            }
        
        return {
            'generated_at': datetime.datetime.now().isoformat(),
            'current_week': current_week,
            'week_comparison': week_comparison,
            'monthly_trends': trends,
            'focus_analysis': focus_analysis,
            'goal_progress': goal_progress,
            'key_insights': self._generate_key_insights(current_week, trends, focus_analysis),
            'recommendations': self._generate_comprehensive_recommendations(current_week, trends, focus_analysis)
        }
    
    def _generate_key_insights(self, week_data: Dict, trends: Dict, focus_data: Dict) -> List[str]:
        """Generate key insights from the data"""
        insights = []
        
        # Weekly insights
        if week_data.get('avg_productivity_score', 0) > 70:
            insights.append("High productivity week - great job maintaining consistent output!")
        elif week_data.get('avg_productivity_score', 0) < 40:
            insights.append("Lower productivity this week - consider reviewing your planning approach")
        
        # Trend insights
        if trends.get('trend_direction') == 'improving':
            insights.append("Positive productivity trend over the past month")
        elif trends.get('trend_direction') == 'declining':
            insights.append("Productivity has been declining - time to reassess strategies")
        
        # Focus insights
        focus_quality = focus_data.get('focus_quality', '')
        if focus_quality == 'excellent':
            insights.append("Excellent focus patterns - you're maintaining good concentration")
        elif focus_quality == 'needs_improvement':
            insights.append("Focus could be improved - consider techniques to reduce distractions")
        
        return insights
    
    def _generate_comprehensive_recommendations(self, week_data: Dict, trends: Dict, focus_data: Dict) -> List[str]:
        """Generate comprehensive recommendations"""
        recommendations = []
        
        # Add focus recommendations
        recommendations.extend(focus_data.get('recommendations', []))
        
        # Weekly productivity recommendations
        productivity_score = week_data.get('avg_productivity_score', 0)
        if productivity_score < 50:
            recommendations.append("Schedule regular planning sessions to improve organization")
            recommendations.append("Set clear daily goals to increase focus and accountability")
        
        # Category distribution recommendations
        category_dist = week_data.get('category_distribution', {})
        if category_dist.get('task', 0) > category_dist.get('idea', 0) * 3:
            recommendations.append("Balance execution with ideation - schedule time for creative thinking")
        
        # Remove duplicates
        return list(set(recommendations))