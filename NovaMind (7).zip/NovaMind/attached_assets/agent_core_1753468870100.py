import datetime
import json
import logging
import threading
import time
import re
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
import asyncio

logger = logging.getLogger(__name__)

@dataclass
class AgentAction:
    """Represents an action the agent can take"""
    action_type: str
    description: str
    target: Optional[str] = None
    parameters: Optional[Dict[str, Any]] = None
    priority: int = 5  # 1-10, 10 being highest
    scheduled_time: Optional[str] = None
    requires_approval: bool = False
    
@dataclass
class WorkflowStep:
    """Represents a step in an automated workflow"""
    step_id: str
    action: str
    conditions: List[str]
    parameters: Dict[str, Any]
    next_steps: List[str]
    fallback_steps: List[str]

@dataclass
class ProactiveInsight:
    """Represents a proactive insight or suggestion"""
    insight_type: str
    title: str
    description: str
    suggested_actions: List[AgentAction]
    confidence: float
    timestamp: str

class NovaAgent:
    """Advanced AI agent capabilities for Nova"""
    
    def __init__(self, nova_core, openai_integration=None):
        self.nova_core = nova_core
        self.ai = openai_integration
        self.is_active = False
        self.monitoring_thread = None
        self.agent_memory_file = "agent_memory.json"
        self.workflows = {}
        self.active_workflows = {}
        self.pending_actions = []
        self.completed_actions = []
        self.user_preferences = {
            "proactive_level": "medium",  # low, medium, high
            "auto_execute": False,
            "notification_frequency": "hourly",
            "work_hours": {"start": "09:00", "end": "17:00"},
            "timezone": "UTC"
        }
        self.load_agent_memory()
        self.setup_default_workflows()
        
    def load_agent_memory(self):
        """Load agent-specific memory and state"""
        try:
            with open(self.agent_memory_file, 'r') as f:
                data = json.load(f)
                self.pending_actions = [AgentAction(**action) for action in data.get('pending_actions', [])]
                self.completed_actions = data.get('completed_actions', [])
                self.user_preferences.update(data.get('user_preferences', {}))
                self.workflows = data.get('workflows', {})
        except (FileNotFoundError, json.JSONDecodeError):
            logger.info("No agent memory found, starting fresh")
    
    def save_agent_memory(self):
        """Save agent state and memory"""
        try:
            data = {
                'pending_actions': [asdict(action) for action in self.pending_actions],
                'completed_actions': self.completed_actions[-100:],  # Keep last 100
                'user_preferences': self.user_preferences,
                'workflows': self.workflows,
                'last_updated': datetime.datetime.now().isoformat()
            }
            with open(self.agent_memory_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving agent memory: {e}")
    
    def setup_default_workflows(self):
        """Setup default intelligent workflows"""
        self.workflows = {
            "daily_review": {
                "name": "Daily Task Review",
                "description": "Review and prioritize daily tasks",
                "trigger": "time:09:00",
                "steps": [
                    {"action": "analyze_pending_tasks", "conditions": []},
                    {"action": "suggest_priorities", "conditions": []},
                    {"action": "check_overdue_items", "conditions": []},
                    {"action": "generate_daily_plan", "conditions": []}
                ]
            },
            "smart_reminders": {
                "name": "Intelligent Reminder System",
                "description": "Proactively remind based on context",
                "trigger": "continuous",
                "steps": [
                    {"action": "check_due_items", "conditions": []},
                    {"action": "analyze_patterns", "conditions": []},
                    {"action": "send_contextual_reminders", "conditions": []}
                ]
            },
            "project_tracking": {
                "name": "Project Progress Monitoring",
                "description": "Track project milestones and deadlines",
                "trigger": "entry_update",
                "steps": [
                    {"action": "analyze_project_entries", "conditions": []},
                    {"action": "calculate_progress", "conditions": []},
                    {"action": "suggest_next_actions", "conditions": []}
                ]
            }
        }
    
    def start_monitoring(self):
        """Start proactive monitoring"""
        if self.is_active:
            return
        
        self.is_active = True
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitoring_thread.start()
        logger.info("Nova agent monitoring started")
    
    def stop_monitoring(self):
        """Stop proactive monitoring"""
        self.is_active = False
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=5)
        logger.info("Nova agent monitoring stopped")
    
    def _monitoring_loop(self):
        """Main monitoring loop for proactive behavior"""
        last_check = datetime.datetime.now()
        
        while self.is_active:
            try:
                current_time = datetime.datetime.now()
                
                # Run checks every minute
                if (current_time - last_check).seconds >= 60:
                    self._perform_proactive_checks()
                    last_check = current_time
                
                # Process pending actions
                self._process_pending_actions()
                
                # Sleep for 30 seconds before next iteration
                time.sleep(30)
                
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                time.sleep(60)  # Wait longer on error
    
    def _perform_proactive_checks(self):
        """Perform proactive analysis and generate insights"""
        try:
            # Check for overdue items
            self._check_overdue_items()
            
            # Analyze patterns
            self._analyze_user_patterns()
            
            # Generate suggestions
            self._generate_proactive_suggestions()
            
            # Check for workflow triggers
            self._check_workflow_triggers()
            
        except Exception as e:
            logger.error(f"Error in proactive checks: {e}")
    
    def _check_overdue_items(self):
        """Check for overdue tasks and reminders"""
        current_time = datetime.datetime.now()
        overdue_items = []
        
        for entry in self.nova_core.memory_log:
            if entry.get('due_date'):
                try:
                    due_date = datetime.datetime.strptime(entry['due_date'], "%Y-%m-%d %H:%M:%S")
                    if due_date < current_time and entry['category'] in ['task', 'reminder']:
                        overdue_items.append(entry)
                except ValueError:
                    continue
        
        if overdue_items:
            action = AgentAction(
                action_type="notification",
                description=f"You have {len(overdue_items)} overdue items",
                parameters={"items": overdue_items, "type": "overdue"},
                priority=8
            )
            self.add_pending_action(action)
    
    def _analyze_user_patterns(self):
        """Analyze user behavior patterns for insights"""
        entries = self.nova_core.memory_log
        if len(entries) < 5:
            return  # Need more data
        
        # Analyze activity patterns
        entry_times = []
        categories = {}
        tags = {}
        
        for entry in entries[-20:]:  # Last 20 entries
            timestamp = datetime.datetime.strptime(entry['timestamp'], "%Y-%m-%d %H:%M:%S")
            entry_times.append(timestamp.hour)
            
            category = entry['category']
            categories[category] = categories.get(category, 0) + 1
            
            for tag in entry.get('tags', []):
                tags[tag] = tags.get(tag, 0) + 1
        
        # Generate insights based on patterns
        insights = []
        
        # Most active hours
        if entry_times:
            most_active_hour = max(set(entry_times), key=entry_times.count)
            insights.append(f"Most active hour: {most_active_hour}:00")
        
        # Most used categories
        if categories:
            top_category = max(categories, key=categories.get)
            insights.append(f"Primary focus: {top_category} ({categories[top_category]} entries)")
        
        # Most used tags
        if tags:
            top_tag = max(tags, key=tags.get)
            insights.append(f"Top project: {top_tag} ({tags[top_tag]} entries)")
        
        if insights:
            insight = ProactiveInsight(
                insight_type="pattern_analysis",
                title="Usage Patterns Detected",
                description="; ".join(insights),
                suggested_actions=[],
                confidence=0.8,
                timestamp=datetime.datetime.now().isoformat()
            )
            self._store_insight(insight)
    
    def _generate_proactive_suggestions(self):
        """Generate intelligent suggestions based on current state"""
        entries = self.nova_core.memory_log
        current_time = datetime.datetime.now()
        
        # Suggest daily planning if no tasks for today
        today_tasks = [e for e in entries if 
                      e.get('due_date') and 
                      e['category'] == 'task' and
                      e['due_date'].startswith(current_time.strftime("%Y-%m-%d"))]
        
        if not today_tasks and current_time.hour < 10:
            action = AgentAction(
                action_type="suggestion",
                description="Would you like me to help plan your day? I can review your pending tasks and suggest priorities.",
                parameters={"type": "daily_planning"},
                priority=6
            )
            self.add_pending_action(action)
        
        # Suggest project reviews for active projects
        project_tags = {}
        for entry in entries[-30:]:  # Last 30 entries
            for tag in entry.get('tags', []):
                if tag.startswith('#'):
                    project_tags[tag] = project_tags.get(tag, 0) + 1
        
        for tag, count in project_tags.items():
            if count >= 5:  # Active project
                last_entry_date = None
                for entry in reversed(entries):
                    if tag in entry.get('tags', []):
                        last_entry_date = datetime.datetime.strptime(entry['timestamp'], "%Y-%m-%d %H:%M:%S")
                        break
                
                if last_entry_date and (current_time - last_entry_date).days >= 3:
                    action = AgentAction(
                        action_type="suggestion",
                        description=f"You haven't updated {tag} project in {(current_time - last_entry_date).days} days. Need any help organizing next steps?",
                        parameters={"type": "project_check", "project": tag},
                        priority=5
                    )
                    self.add_pending_action(action)
    
    def _check_workflow_triggers(self):
        """Check if any workflows should be triggered"""
        current_time = datetime.datetime.now()
        
        for workflow_id, workflow in self.workflows.items():
            trigger = workflow.get('trigger', '')
            
            if trigger.startswith('time:'):
                trigger_time = trigger.split(':')[1]
                if current_time.strftime("%H:%M") == trigger_time:
                    self._execute_workflow(workflow_id, workflow)
            elif trigger == 'continuous':
                # Run continuous workflows every hour
                if current_time.minute == 0:
                    self._execute_workflow(workflow_id, workflow)
    
    def _execute_workflow(self, workflow_id: str, workflow: Dict):
        """Execute a workflow"""
        if workflow_id in self.active_workflows:
            return  # Already running
        
        self.active_workflows[workflow_id] = {
            'started': datetime.datetime.now().isoformat(),
            'current_step': 0,
            'status': 'running'
        }
        
        logger.info(f"Executing workflow: {workflow['name']}")
        
        # For now, create a summary action for the workflow
        action = AgentAction(
            action_type="workflow_execution",
            description=f"Executing {workflow['name']}: {workflow['description']}",
            parameters={"workflow_id": workflow_id, "workflow": workflow},
            priority=7
        )
        self.add_pending_action(action)
    
    def _process_pending_actions(self):
        """Process pending actions based on priority and settings"""
        if not self.pending_actions:
            return
        
        # Sort by priority (highest first)
        self.pending_actions.sort(key=lambda x: x.priority, reverse=True)
        
        # Process high priority actions immediately
        to_process = []
        for action in self.pending_actions[:]:
            if action.priority >= 8:
                to_process.append(action)
                self.pending_actions.remove(action)
        
        # Execute actions that don't require approval
        for action in to_process:
            if not action.requires_approval or self.user_preferences.get('auto_execute', False):
                self._execute_action(action)
    
    def _execute_action(self, action: AgentAction):
        """Execute a specific action"""
        try:
            logger.info(f"Executing action: {action.description}")
            
            # Record completion
            completion_record = {
                'action': asdict(action),
                'executed_at': datetime.datetime.now().isoformat(),
                'status': 'completed'
            }
            self.completed_actions.append(completion_record)
            
            # Save state
            self.save_agent_memory()
            
        except Exception as e:
            logger.error(f"Error executing action: {e}")
    
    def _store_insight(self, insight: ProactiveInsight):
        """Store a proactive insight"""
        # For now, convert to an action
        action = AgentAction(
            action_type="insight",
            description=f"{insight.title}: {insight.description}",
            parameters={"insight": asdict(insight)},
            priority=4
        )
        self.add_pending_action(action)
    
    def add_pending_action(self, action: AgentAction):
        """Add an action to the pending queue"""
        self.pending_actions.append(action)
        self.save_agent_memory()
    
    def get_pending_actions(self) -> List[AgentAction]:
        """Get all pending actions"""
        return self.pending_actions.copy()
    
    def approve_action(self, action_index: int) -> bool:
        """Approve and execute a pending action"""
        try:
            if 0 <= action_index < len(self.pending_actions):
                action = self.pending_actions.pop(action_index)
                self._execute_action(action)
                return True
        except Exception as e:
            logger.error(f"Error approving action: {e}")
        return False
    
    def dismiss_action(self, action_index: int) -> bool:
        """Dismiss a pending action"""
        try:
            if 0 <= action_index < len(self.pending_actions):
                self.pending_actions.pop(action_index)
                self.save_agent_memory()
                return True
        except Exception as e:
            logger.error(f"Error dismissing action: {e}")
        return False
    
    def get_agent_status(self) -> Dict[str, Any]:
        """Get current agent status and statistics"""
        return {
            'active': self.is_active,
            'pending_actions': len(self.pending_actions),
            'completed_actions_today': len([
                a for a in self.completed_actions 
                if a.get('executed_at', '').startswith(datetime.datetime.now().strftime("%Y-%m-%d"))
            ]),
            'active_workflows': len(self.active_workflows),
            'preferences': self.user_preferences,
            'last_check': datetime.datetime.now().isoformat()
        }
    
    def update_preferences(self, preferences: Dict[str, Any]):
        """Update user preferences for agent behavior"""
        self.user_preferences.update(preferences)
        self.save_agent_memory()
        
    def create_custom_workflow(self, name: str, description: str, steps: List[Dict], trigger: str):
        """Create a custom workflow"""
        workflow_id = name.lower().replace(' ', '_')
        self.workflows[workflow_id] = {
            'name': name,
            'description': description,
            'trigger': trigger,
            'steps': steps,
            'created_at': datetime.datetime.now().isoformat()
        }
        self.save_agent_memory()
        return workflow_id