// Nova AI Assistant - Frontend JavaScript

class NovaApp {
    constructor() {
        this.chatMessages = document.getElementById('chatMessages');
        this.messageInput = document.getElementById('messageInput');
        this.voiceBtn = document.getElementById('voiceBtn');
        this.voiceBtnMain = document.getElementById('voiceBtnMain');
        this.speakToggle = document.getElementById('speakToggle');
        this.statusIndicator = document.getElementById('statusIndicator');
        
        this.isRecording = false;
        this.recognition = null;
        this.synthesis = window.speechSynthesis;
        this.shouldSpeak = true;
        
        this.initializeVoiceRecognition();
        this.loadStats();
        this.setupEventListeners();
        
        // Auto-focus input
        this.messageInput.focus();
    }

    setupEventListeners() {
        // Voice button
        this.voiceBtn.addEventListener('click', () => this.toggleVoiceRecording());
        
        // TTS toggle
        this.speakToggle.addEventListener('click', () => this.toggleTTS());
        
        // Auto-resize textarea (if we change to textarea later)
        this.messageInput.addEventListener('input', () => {
            // Auto-scroll to bottom when typing
            this.scrollToBottom();
        });
    }

    initializeVoiceRecognition() {
        if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
            console.warn('Speech recognition not supported');
            this.voiceBtn.disabled = true;
            this.voiceBtn.innerHTML = '<i class="fas fa-microphone-slash me-1"></i>Not Supported';
            return;
        }

        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        this.recognition = new SpeechRecognition();
        
        this.recognition.continuous = false;
        this.recognition.interimResults = false;
        this.recognition.lang = 'en-US';

        this.recognition.onstart = () => {
            this.isRecording = true;
            
            // Update sidebar button
            this.voiceBtn.classList.add('recording', 'btn-danger');
            this.voiceBtn.classList.remove('btn-outline-primary');
            document.getElementById('voiceBtnText').textContent = 'Recording...';
            this.voiceBtn.innerHTML = '<i class="fas fa-stop me-1"></i>Stop Recording';
            
            // Update main button
            this.voiceBtnMain.classList.add('recording', 'btn-danger');
            this.voiceBtnMain.classList.remove('btn-outline-primary');
            this.voiceBtnMain.innerHTML = '<i class="fas fa-stop"></i>';
            this.voiceBtnMain.title = 'Stop Recording';
        };

        this.recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript;
            this.messageInput.value = transcript;
            this.sendMessage();
        };

        this.recognition.onerror = (event) => {
            console.error('Speech recognition error:', event.error);
            this.addMessage('nova', `Voice recognition error: ${event.error}`, 'error');
            this.resetVoiceButton();
        };

        this.recognition.onend = () => {
            this.resetVoiceButton();
        };
    }

    toggleVoiceRecording() {
        if (!this.recognition) return;

        if (this.isRecording) {
            this.recognition.stop();
        } else {
            this.recognition.start();
        }
    }

    resetVoiceButton() {
        this.isRecording = false;
        
        // Reset sidebar button
        this.voiceBtn.classList.remove('recording', 'btn-danger');
        this.voiceBtn.classList.add('btn-outline-primary');
        this.voiceBtn.innerHTML = '<i class="fas fa-microphone me-1"></i><span id="voiceBtnText">Start Voice</span>';
        
        // Reset main button
        this.voiceBtnMain.classList.remove('recording', 'btn-danger');
        this.voiceBtnMain.classList.add('btn-outline-primary');
        this.voiceBtnMain.innerHTML = '<i class="fas fa-microphone"></i>';
        this.voiceBtnMain.title = 'Voice Input';
    }

    toggleTTS() {
        this.shouldSpeak = !this.shouldSpeak;
        const toggleText = document.getElementById('speakToggleText');
        const icon = this.speakToggle.querySelector('i');
        
        if (this.shouldSpeak) {
            toggleText.textContent = 'TTS: On';
            icon.className = 'fas fa-volume-up me-1';
            this.speakToggle.classList.remove('btn-outline-secondary');
            this.speakToggle.classList.add('btn-outline-primary');
        } else {
            toggleText.textContent = 'TTS: Off';
            icon.className = 'fas fa-volume-mute me-1';
            this.speakToggle.classList.remove('btn-outline-primary');
            this.speakToggle.classList.add('btn-outline-secondary');
        }
    }

    speak(text) {
        if (!this.shouldSpeak || !this.synthesis) return;

        // Stop any ongoing speech
        this.synthesis.cancel();

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 0.9;
        utterance.pitch = 1;
        utterance.volume = 0.8;

        // Try to use a more natural voice
        const voices = this.synthesis.getVoices();
        const preferredVoice = voices.find(voice => 
            voice.name.includes('Natural') || 
            voice.name.includes('Enhanced') ||
            voice.name.includes('Premium')
        ) || voices.find(voice => voice.lang.startsWith('en'));

        if (preferredVoice) {
            utterance.voice = preferredVoice;
        }

        this.synthesis.speak(utterance);
    }

    async sendMessage(message = null) {
        const text = message || this.messageInput.value.trim();
        if (!text) return;

        // Add user message to chat
        this.addMessage('user', text);
        
        // Clear input
        if (!message) {
            this.messageInput.value = '';
        }

        // Show typing indicator
        this.showTypingIndicator();

        try {
            const response = await fetch('/api/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message: text })
            });

            const data = await response.json();
            
            // Remove typing indicator
            this.hideTypingIndicator();

            if (response.ok) {
                this.addMessage('nova', data.response, data.type, data);
                
                // Speak response if enabled and it's a voice response
                if (data.should_speak || data.type === 'voice_success') {
                    this.speak(data.response);
                }
                
                // Refresh stats if memory was modified
                if (data.type === 'success' || data.type === 'system') {
                    this.loadStats();
                }
            } else {
                this.addMessage('nova', data.error || 'Something went wrong', 'error');
            }
        } catch (error) {
            this.hideTypingIndicator();
            console.error('Error sending message:', error);
            this.addMessage('nova', 'Connection error. Please try again.', 'error');
        }
    }

    addMessage(sender, text, type = 'normal', data = null) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}-message`;

        const now = new Date();
        const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        if (sender === 'user') {
            messageDiv.innerHTML = `
                <div class="message-content">
                    <div class="message-text">${this.escapeHtml(text)}</div>
                </div>
            `;
        } else {
            let messageContent = '';
            
            if (type === 'error') {
                messageContent = `<div class="error-message">${this.escapeHtml(text)}</div>`;
            } else if (type === 'memory' && data && data.entries) {
                messageContent = this.renderMemoryEntries(text, data.entries, data.summary);
            } else if (type === 'help') {
                messageContent = `<div class="message-text">${this.formatHelpText(text)}</div>`;
            } else {
                messageContent = `<div class="message-text">${this.formatText(text)}</div>`;
            }

            messageDiv.innerHTML = `
                <div class="message-content">
                    <div class="d-flex align-items-start">
                        <div class="avatar bg-primary me-3">
                            <i class="fas fa-robot"></i>
                        </div>
                        <div class="flex-grow-1">
                            <div class="message-header">
                                <strong class="text-primary">Nova</strong>
                                <small class="text-muted ms-2">${timeStr}</small>
                            </div>
                            ${messageContent}
                        </div>
                    </div>
                </div>
            `;
        }

        this.chatMessages.appendChild(messageDiv);
        this.scrollToBottom();
    }

    renderMemoryEntries(responseText, entries, summary) {
        let html = `<div class="message-text">${this.escapeHtml(responseText)}</div>`;
        
        if (summary) {
            html += `<div class="memory-summary mt-2">
                <i class="fas fa-lightbulb me-2"></i><strong>Summary:</strong> ${this.escapeHtml(summary)}
            </div>`;
        }

        if (entries.length > 0) {
            html += '<div class="mt-3">';
            entries.forEach(entry => {
                const categoryColor = this.getCategoryColor(entry.category);
                const tags = entry.tags.map(tag => `<span class="tag-badge">${tag}</span>`).join('');
                
                html += `
                    <div class="memory-entry">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <span class="category-badge badge ${categoryColor}">${entry.category}</span>
                            <small class="text-muted">${entry.timestamp}</small>
                        </div>
                        <div class="entry-text">${this.escapeHtml(entry.text)}</div>
                        <div class="entry-meta mt-2">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>${tags}</div>
                                <div class="small text-muted">
                                    ${entry.due_date ? `Due: ${entry.due_date}` : ''}
                                    ${entry.recurring ? `• Recurring: ${entry.recurring}` : ''}
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            });
            html += '</div>';
        }

        return html;
    }

    getCategoryColor(category) {
        const colors = {
            'task': 'bg-warning',
            'idea': 'bg-info',
            'reminder': 'bg-danger',
            'note': 'bg-secondary',
            'recurring_reminder': 'bg-primary',
            'uncategorized': 'bg-dark'
        };
        return colors[category] || 'bg-secondary';
    }

    formatHelpText(text) {
        return text.replace(/\n/g, '<br>').replace(/•/g, '<i class="fas fa-chevron-right me-2 text-primary"></i>');
    }

    formatText(text) {
        // Format text with basic markdown-like formatting
        return text
            .replace(/\n/g, '<br>')
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/#(\w+)/g, '<span class="tag-badge">#$1</span>');
    }

    showTypingIndicator() {
        const typingDiv = document.createElement('div');
        typingDiv.id = 'typingIndicator';
        typingDiv.className = 'message nova-message';
        typingDiv.innerHTML = `
            <div class="message-content">
                <div class="d-flex align-items-start">
                    <div class="avatar bg-primary me-3">
                        <i class="fas fa-robot"></i>
                    </div>
                    <div class="flex-grow-1">
                        <div class="typing-indicator">
                            <span class="me-2">Nova is thinking</span>
                            <div class="typing-dots">
                                <div class="typing-dot"></div>
                                <div class="typing-dot"></div>
                                <div class="typing-dot"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        this.chatMessages.appendChild(typingDiv);
        this.scrollToBottom();
    }

    hideTypingIndicator() {
        const indicator = document.getElementById('typingIndicator');
        if (indicator) {
            indicator.remove();
        }
    }

    async loadStats() {
        try {
            const response = await fetch('/api/stats');
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            
            const stats = await response.json();
            
            const statsContent = document.getElementById('statsContent');
            if (!statsContent) {
                console.warn('Stats content element not found');
                return;
            }
            
            if (!stats || stats.total_entries === 0) {
                statsContent.innerHTML = '<div class="text-muted">No memories yet</div>';
            } else {
                let html = `<div class="mb-2"><strong>${stats.total_entries}</strong> total entries</div>`;
                
                if (stats.categories && Object.keys(stats.categories).length > 0) {
                    html += '<div class="mb-2"><strong>Categories:</strong></div>';
                    for (const [category, count] of Object.entries(stats.categories)) {
                        html += `<div class="d-flex justify-content-between">
                            <span>${category}</span>
                            <span class="badge bg-secondary">${count}</span>
                        </div>`;
                    }
                }
                
                statsContent.innerHTML = html;
            }
        } catch (error) {
            console.error('Error loading stats:', error);
            const statsContent = document.getElementById('statsContent');
            if (statsContent) {
                statsContent.innerHTML = '<div class="text-muted">Stats unavailable</div>';
            }
        }
    }

    scrollToBottom() {
        setTimeout(() => {
            this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
        }, 100);
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Global functions for quick actions
function sendQuickMessage(message) {
    if (window.app) {
        window.app.sendMessage(message);
    } else {
        console.error('Nova app not initialized');
    }
}

// Agent functionality
async function requestDailyPlan() {
    try {
        const response = await fetch('/api/agent/daily-plan');
        const data = await response.json();
        
        if (response.ok && data.daily_plan) {
            displayDailyPlan(data.daily_plan);
        } else {
            window.app.addMessage('nova', 'Unable to generate daily plan at this time.', 'error');
        }
    } catch (error) {
        console.error('Daily plan error:', error);
        window.app.addMessage('nova', 'Error generating daily plan.', 'error');
    }
}

async function getInsights() {
    try {
        const response = await fetch('/api/agent/insights');
        const data = await response.json();
        
        if (response.ok) {
            displayInsights(data.insights, data.summary);
        } else {
            window.app.addMessage('nova', 'Unable to generate insights at this time.', 'error');
        }
    } catch (error) {
        console.error('Insights error:', error);
        window.app.addMessage('nova', 'Error generating insights.', 'error');
    }
}

async function showAgentStatus() {
    try {
        const response = await fetch('/api/agent/status');
        const data = await response.json();
        
        if (response.ok) {
            displayAgentStatus(data.status, data.pending_actions);
        } else {
            window.app.addMessage('nova', 'Unable to get agent status.', 'error');
        }
    } catch (error) {
        console.error('Agent status error:', error);
        window.app.addMessage('nova', 'Error getting agent status.', 'error');
    }
}

function displayDailyPlan(plan) {
    let planHtml = '<div class="daily-plan-container">';
    planHtml += '<h5><i class="fas fa-calendar-day me-2"></i>Your Daily Plan</h5>';
    
    const timeSlots = {
        'morning': '🌅 Morning (9:00 - 12:00)',
        'afternoon': '☀️ Afternoon (12:00 - 17:00)',
        'evening': '🌆 Evening (17:00 - 20:00)',
        'flexible': '⏰ Flexible Time'
    };
    
    for (const [slot, tasks] of Object.entries(plan)) {
        if (tasks && tasks.length > 0) {
            planHtml += `<div class="time-slot mb-3">`;
            planHtml += `<h6 class="text-info">${timeSlots[slot]}</h6>`;
            planHtml += '<ul class="list-unstyled ms-3">';
            
            tasks.forEach(task => {
                planHtml += `<li class="mb-2">`;
                planHtml += `<i class="fas fa-check-circle me-2 text-success"></i>`;
                planHtml += `${task.text}`;
                if (task.due_date) {
                    planHtml += ` <small class="text-muted">(Due: ${task.due_date})</small>`;
                }
                planHtml += '</li>';
            });
            
            planHtml += '</ul></div>';
        }
    }
    
    planHtml += '</div>';
    
    window.app.addMessage('nova', planHtml, 'daily_plan');
}

function displayInsights(insights, summary) {
    let insightsHtml = '<div class="insights-container">';
    insightsHtml += '<h5><i class="fas fa-chart-line me-2"></i>Productivity Insights</h5>';
    
    if (summary) {
        insightsHtml += `<div class="alert alert-info mb-3">${summary}</div>`;
    }
    
    insights.forEach((insight, index) => {
        insightsHtml += '<div class="insight-item mb-3">';
        
        if (insight.total_tasks !== undefined) {
            insightsHtml += `<h6>📊 Task Analysis</h6>`;
            insightsHtml += `<p>Total tasks: <strong>${insight.total_tasks}</strong></p>`;
            
            if (insight.urgent_tasks && insight.urgent_tasks.length > 0) {
                insightsHtml += `<p class="text-warning">⚡ ${insight.urgent_tasks.length} urgent tasks</p>`;
            }
            
            if (insight.overdue_tasks && insight.overdue_tasks.length > 0) {
                insightsHtml += `<p class="text-danger">🚨 ${insight.overdue_tasks.length} overdue tasks</p>`;
            }
        }
        
        if (insight.suggestions) {
            insightsHtml += '<h6>💡 Priority Suggestions</h6>';
            insight.suggestions.forEach(suggestion => {
                const priorityColors = {
                    'urgent': 'text-danger',
                    'high': 'text-warning', 
                    'medium': 'text-info'
                };
                insightsHtml += `<p class="${priorityColors[suggestion.priority] || 'text-secondary'}">`;
                insightsHtml += `${suggestion.action}`;
                insightsHtml += '</p>';
            });
        }
        
        if (insight.most_active_times) {
            insightsHtml += '<h6>⏰ Activity Patterns</h6>';
            const topTime = insight.most_active_times[0];
            insightsHtml += `<p>Most active: ${topTime[0]}:00 (${topTime[1]} entries)</p>`;
        }
        
        insightsHtml += '</div>';
    });
    
    insightsHtml += '</div>';
    
    window.app.addMessage('nova', insightsHtml, 'insights');
}

function displayAgentStatus(status, pendingActions) {
    let statusHtml = '<div class="agent-status-container">';
    statusHtml += '<h5><i class="fas fa-cog me-2"></i>Agent Status</h5>';
    
    const statusColor = status.active ? 'text-success' : 'text-secondary';
    statusHtml += `<p>Status: <span class="${statusColor}">${status.active ? '🟢 Active' : '⚫ Inactive'}</span></p>`;
    statusHtml += `<p>Pending actions: <strong>${status.pending_actions}</strong></p>`;
    statusHtml += `<p>Actions completed today: <strong>${status.completed_actions_today}</strong></p>`;
    
    if (pendingActions && pendingActions.length > 0) {
        statusHtml += '<h6 class="mt-3">📋 Pending Actions</h6>';
        pendingActions.forEach((action, index) => {
            const priorityColors = {
                10: 'danger', 9: 'danger', 8: 'warning',
                7: 'warning', 6: 'info', 5: 'info',
                4: 'secondary', 3: 'secondary', 2: 'secondary', 1: 'secondary'
            };
            const priorityColor = priorityColors[action.priority] || 'secondary';
            
            statusHtml += '<div class="pending-action mb-2 p-2 border rounded">';
            statusHtml += `<span class="badge bg-${priorityColor} me-2">Priority ${action.priority}</span>`;
            statusHtml += `<strong>${action.type}</strong>: ${action.description}`;
            statusHtml += '</div>';
        });
    }
    
    statusHtml += '</div>';
    
    window.app.addMessage('nova', statusHtml, 'agent_status');
}

function clearChat() {
    const chatMessages = document.getElementById('chatMessages');
    chatMessages.innerHTML = `
        <div class="message nova-message">
            <div class="message-content">
                <div class="d-flex align-items-start">
                    <div class="avatar bg-primary me-3">
                        <i class="fas fa-robot"></i>
                    </div>
                    <div class="flex-grow-1">
                        <div class="message-header">
                            <strong class="text-primary">Nova</strong>
                            <small class="text-muted ms-2">Just now</small>
                        </div>
                        <div class="message-text">
                            Chat cleared. How can I help you today?
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function handleKeyPress(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        if (window.app) {
            window.app.sendMessage();
        } else {
            console.error('Nova app not initialized');
        }
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new NovaApp();
    
    // Load available voices for speech synthesis
    if (window.speechSynthesis) {
        window.speechSynthesis.onvoiceschanged = () => {
            console.log('Speech synthesis voices loaded');
        };
    }
});

// Handle visibility change to manage speech synthesis
document.addEventListener('visibilitychange', () => {
    if (document.hidden && window.speechSynthesis) {
        window.speechSynthesis.cancel();
    }
});
